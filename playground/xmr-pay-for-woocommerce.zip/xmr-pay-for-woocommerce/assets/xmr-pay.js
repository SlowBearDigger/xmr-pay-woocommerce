/*! <xmr-pay> — sovereign Monero checkout widget. one self-hosted file: no CDN, no third-party requests, QR generated locally.
 * bundles qrcode-generator@1.5.2 (c) Kazuhiko Arase, MIT — https://github.com/kazuhikoarase/qrcode-generator */
(function(){
//---------------------------------------------------------------------
//
// QR Code Generator for JavaScript
//
// Copyright (c) 2009 Kazuhiko Arase
//
// URL: http://www.d-project.com/
//
// Licensed under the MIT license:
//  http://www.opensource.org/licenses/mit-license.php
//
// The word 'QR Code' is registered trademark of
// DENSO WAVE INCORPORATED
//  http://www.denso-wave.com/qrcode/faqpatent-e.html
//
//---------------------------------------------------------------------

var qrcode = function() {

  //---------------------------------------------------------------------
  // qrcode
  //---------------------------------------------------------------------

  /**
   * qrcode
   * @param typeNumber 1 to 40
   * @param errorCorrectionLevel 'L','M','Q','H'
   */
  var qrcode = function(typeNumber, errorCorrectionLevel) {

    var PAD0 = 0xEC;
    var PAD1 = 0x11;

    var _typeNumber = typeNumber;
    var _errorCorrectionLevel = QRErrorCorrectionLevel[errorCorrectionLevel];
    var _modules = null;
    var _moduleCount = 0;
    var _dataCache = null;
    var _dataList = [];

    var _this = {};

    var makeImpl = function(test, maskPattern) {

      _moduleCount = _typeNumber * 4 + 17;
      _modules = function(moduleCount) {
        var modules = new Array(moduleCount);
        for (var row = 0; row < moduleCount; row += 1) {
          modules[row] = new Array(moduleCount);
          for (var col = 0; col < moduleCount; col += 1) {
            modules[row][col] = null;
          }
        }
        return modules;
      }(_moduleCount);

      setupPositionProbePattern(0, 0);
      setupPositionProbePattern(_moduleCount - 7, 0);
      setupPositionProbePattern(0, _moduleCount - 7);
      setupPositionAdjustPattern();
      setupTimingPattern();
      setupTypeInfo(test, maskPattern);

      if (_typeNumber >= 7) {
        setupTypeNumber(test);
      }

      if (_dataCache == null) {
        _dataCache = createData(_typeNumber, _errorCorrectionLevel, _dataList);
      }

      mapData(_dataCache, maskPattern);
    };

    var setupPositionProbePattern = function(row, col) {

      for (var r = -1; r <= 7; r += 1) {

        if (row + r <= -1 || _moduleCount <= row + r) continue;

        for (var c = -1; c <= 7; c += 1) {

          if (col + c <= -1 || _moduleCount <= col + c) continue;

          if ( (0 <= r && r <= 6 && (c == 0 || c == 6) )
              || (0 <= c && c <= 6 && (r == 0 || r == 6) )
              || (2 <= r && r <= 4 && 2 <= c && c <= 4) ) {
            _modules[row + r][col + c] = true;
          } else {
            _modules[row + r][col + c] = false;
          }
        }
      }
    };

    var getBestMaskPattern = function() {

      var minLostPoint = 0;
      var pattern = 0;

      for (var i = 0; i < 8; i += 1) {

        makeImpl(true, i);

        var lostPoint = QRUtil.getLostPoint(_this);

        if (i == 0 || minLostPoint > lostPoint) {
          minLostPoint = lostPoint;
          pattern = i;
        }
      }

      return pattern;
    };

    var setupTimingPattern = function() {

      for (var r = 8; r < _moduleCount - 8; r += 1) {
        if (_modules[r][6] != null) {
          continue;
        }
        _modules[r][6] = (r % 2 == 0);
      }

      for (var c = 8; c < _moduleCount - 8; c += 1) {
        if (_modules[6][c] != null) {
          continue;
        }
        _modules[6][c] = (c % 2 == 0);
      }
    };

    var setupPositionAdjustPattern = function() {

      var pos = QRUtil.getPatternPosition(_typeNumber);

      for (var i = 0; i < pos.length; i += 1) {

        for (var j = 0; j < pos.length; j += 1) {

          var row = pos[i];
          var col = pos[j];

          if (_modules[row][col] != null) {
            continue;
          }

          for (var r = -2; r <= 2; r += 1) {

            for (var c = -2; c <= 2; c += 1) {

              if (r == -2 || r == 2 || c == -2 || c == 2
                  || (r == 0 && c == 0) ) {
                _modules[row + r][col + c] = true;
              } else {
                _modules[row + r][col + c] = false;
              }
            }
          }
        }
      }
    };

    var setupTypeNumber = function(test) {

      var bits = QRUtil.getBCHTypeNumber(_typeNumber);

      for (var i = 0; i < 18; i += 1) {
        var mod = (!test && ( (bits >> i) & 1) == 1);
        _modules[Math.floor(i / 3)][i % 3 + _moduleCount - 8 - 3] = mod;
      }

      for (var i = 0; i < 18; i += 1) {
        var mod = (!test && ( (bits >> i) & 1) == 1);
        _modules[i % 3 + _moduleCount - 8 - 3][Math.floor(i / 3)] = mod;
      }
    };

    var setupTypeInfo = function(test, maskPattern) {

      var data = (_errorCorrectionLevel << 3) | maskPattern;
      var bits = QRUtil.getBCHTypeInfo(data);

      // vertical
      for (var i = 0; i < 15; i += 1) {

        var mod = (!test && ( (bits >> i) & 1) == 1);

        if (i < 6) {
          _modules[i][8] = mod;
        } else if (i < 8) {
          _modules[i + 1][8] = mod;
        } else {
          _modules[_moduleCount - 15 + i][8] = mod;
        }
      }

      // horizontal
      for (var i = 0; i < 15; i += 1) {

        var mod = (!test && ( (bits >> i) & 1) == 1);

        if (i < 8) {
          _modules[8][_moduleCount - i - 1] = mod;
        } else if (i < 9) {
          _modules[8][15 - i - 1 + 1] = mod;
        } else {
          _modules[8][15 - i - 1] = mod;
        }
      }

      // fixed module
      _modules[_moduleCount - 8][8] = (!test);
    };

    var mapData = function(data, maskPattern) {

      var inc = -1;
      var row = _moduleCount - 1;
      var bitIndex = 7;
      var byteIndex = 0;
      var maskFunc = QRUtil.getMaskFunction(maskPattern);

      for (var col = _moduleCount - 1; col > 0; col -= 2) {

        if (col == 6) col -= 1;

        while (true) {

          for (var c = 0; c < 2; c += 1) {

            if (_modules[row][col - c] == null) {

              var dark = false;

              if (byteIndex < data.length) {
                dark = ( ( (data[byteIndex] >>> bitIndex) & 1) == 1);
              }

              var mask = maskFunc(row, col - c);

              if (mask) {
                dark = !dark;
              }

              _modules[row][col - c] = dark;
              bitIndex -= 1;

              if (bitIndex == -1) {
                byteIndex += 1;
                bitIndex = 7;
              }
            }
          }

          row += inc;

          if (row < 0 || _moduleCount <= row) {
            row -= inc;
            inc = -inc;
            break;
          }
        }
      }
    };

    var createBytes = function(buffer, rsBlocks) {

      var offset = 0;

      var maxDcCount = 0;
      var maxEcCount = 0;

      var dcdata = new Array(rsBlocks.length);
      var ecdata = new Array(rsBlocks.length);

      for (var r = 0; r < rsBlocks.length; r += 1) {

        var dcCount = rsBlocks[r].dataCount;
        var ecCount = rsBlocks[r].totalCount - dcCount;

        maxDcCount = Math.max(maxDcCount, dcCount);
        maxEcCount = Math.max(maxEcCount, ecCount);

        dcdata[r] = new Array(dcCount);

        for (var i = 0; i < dcdata[r].length; i += 1) {
          dcdata[r][i] = 0xff & buffer.getBuffer()[i + offset];
        }
        offset += dcCount;

        var rsPoly = QRUtil.getErrorCorrectPolynomial(ecCount);
        var rawPoly = qrPolynomial(dcdata[r], rsPoly.getLength() - 1);

        var modPoly = rawPoly.mod(rsPoly);
        ecdata[r] = new Array(rsPoly.getLength() - 1);
        for (var i = 0; i < ecdata[r].length; i += 1) {
          var modIndex = i + modPoly.getLength() - ecdata[r].length;
          ecdata[r][i] = (modIndex >= 0)? modPoly.getAt(modIndex) : 0;
        }
      }

      var totalCodeCount = 0;
      for (var i = 0; i < rsBlocks.length; i += 1) {
        totalCodeCount += rsBlocks[i].totalCount;
      }

      var data = new Array(totalCodeCount);
      var index = 0;

      for (var i = 0; i < maxDcCount; i += 1) {
        for (var r = 0; r < rsBlocks.length; r += 1) {
          if (i < dcdata[r].length) {
            data[index] = dcdata[r][i];
            index += 1;
          }
        }
      }

      for (var i = 0; i < maxEcCount; i += 1) {
        for (var r = 0; r < rsBlocks.length; r += 1) {
          if (i < ecdata[r].length) {
            data[index] = ecdata[r][i];
            index += 1;
          }
        }
      }

      return data;
    };

    var createData = function(typeNumber, errorCorrectionLevel, dataList) {

      var rsBlocks = QRRSBlock.getRSBlocks(typeNumber, errorCorrectionLevel);

      var buffer = qrBitBuffer();

      for (var i = 0; i < dataList.length; i += 1) {
        var data = dataList[i];
        buffer.put(data.getMode(), 4);
        buffer.put(data.getLength(), QRUtil.getLengthInBits(data.getMode(), typeNumber) );
        data.write(buffer);
      }

      // calc num max data.
      var totalDataCount = 0;
      for (var i = 0; i < rsBlocks.length; i += 1) {
        totalDataCount += rsBlocks[i].dataCount;
      }

      if (buffer.getLengthInBits() > totalDataCount * 8) {
        throw 'code length overflow. ('
          + buffer.getLengthInBits()
          + '>'
          + totalDataCount * 8
          + ')';
      }

      // end code
      if (buffer.getLengthInBits() + 4 <= totalDataCount * 8) {
        buffer.put(0, 4);
      }

      // padding
      while (buffer.getLengthInBits() % 8 != 0) {
        buffer.putBit(false);
      }

      // padding
      while (true) {

        if (buffer.getLengthInBits() >= totalDataCount * 8) {
          break;
        }
        buffer.put(PAD0, 8);

        if (buffer.getLengthInBits() >= totalDataCount * 8) {
          break;
        }
        buffer.put(PAD1, 8);
      }

      return createBytes(buffer, rsBlocks);
    };

    _this.addData = function(data, mode) {

      mode = mode || 'Byte';

      var newData = null;

      switch(mode) {
      case 'Numeric' :
        newData = qrNumber(data);
        break;
      case 'Alphanumeric' :
        newData = qrAlphaNum(data);
        break;
      case 'Byte' :
        newData = qr8BitByte(data);
        break;
      case 'Kanji' :
        newData = qrKanji(data);
        break;
      default :
        throw 'mode:' + mode;
      }

      _dataList.push(newData);
      _dataCache = null;
    };

    _this.isDark = function(row, col) {
      if (row < 0 || _moduleCount <= row || col < 0 || _moduleCount <= col) {
        throw row + ',' + col;
      }
      return _modules[row][col];
    };

    _this.getModuleCount = function() {
      return _moduleCount;
    };

    _this.make = function() {
      if (_typeNumber < 1) {
        var typeNumber = 1;

        for (; typeNumber < 40; typeNumber++) {
          var rsBlocks = QRRSBlock.getRSBlocks(typeNumber, _errorCorrectionLevel);
          var buffer = qrBitBuffer();

          for (var i = 0; i < _dataList.length; i++) {
            var data = _dataList[i];
            buffer.put(data.getMode(), 4);
            buffer.put(data.getLength(), QRUtil.getLengthInBits(data.getMode(), typeNumber) );
            data.write(buffer);
          }

          var totalDataCount = 0;
          for (var i = 0; i < rsBlocks.length; i++) {
            totalDataCount += rsBlocks[i].dataCount;
          }

          if (buffer.getLengthInBits() <= totalDataCount * 8) {
            break;
          }
        }

        _typeNumber = typeNumber;
      }

      makeImpl(false, getBestMaskPattern() );
    };

    _this.createTableTag = function(cellSize, margin) {

      cellSize = cellSize || 2;
      margin = (typeof margin == 'undefined')? cellSize * 4 : margin;

      var qrHtml = '';

      qrHtml += '<table style="';
      qrHtml += ' border-width: 0px; border-style: none;';
      qrHtml += ' border-collapse: collapse;';
      qrHtml += ' padding: 0px; margin: ' + margin + 'px;';
      qrHtml += '">';
      qrHtml += '<tbody>';

      for (var r = 0; r < _this.getModuleCount(); r += 1) {

        qrHtml += '<tr>';

        for (var c = 0; c < _this.getModuleCount(); c += 1) {
          qrHtml += '<td style="';
          qrHtml += ' border-width: 0px; border-style: none;';
          qrHtml += ' border-collapse: collapse;';
          qrHtml += ' padding: 0px; margin: 0px;';
          qrHtml += ' width: ' + cellSize + 'px;';
          qrHtml += ' height: ' + cellSize + 'px;';
          qrHtml += ' background-color: ';
          qrHtml += _this.isDark(r, c)? '#000000' : '#ffffff';
          qrHtml += ';';
          qrHtml += '"/>';
        }

        qrHtml += '</tr>';
      }

      qrHtml += '</tbody>';
      qrHtml += '</table>';

      return qrHtml;
    };

    _this.createSvgTag = function(cellSize, margin, alt, title) {

      var opts = {};
      if (typeof arguments[0] == 'object') {
        // Called by options.
        opts = arguments[0];
        // overwrite cellSize and margin.
        cellSize = opts.cellSize;
        margin = opts.margin;
        alt = opts.alt;
        title = opts.title;
      }

      cellSize = cellSize || 2;
      margin = (typeof margin == 'undefined')? cellSize * 4 : margin;

      // Compose alt property surrogate
      alt = (typeof alt === 'string') ? {text: alt} : alt || {};
      alt.text = alt.text || null;
      alt.id = (alt.text) ? alt.id || 'qrcode-description' : null;

      // Compose title property surrogate
      title = (typeof title === 'string') ? {text: title} : title || {};
      title.text = title.text || null;
      title.id = (title.text) ? title.id || 'qrcode-title' : null;

      var size = _this.getModuleCount() * cellSize + margin * 2;
      var c, mc, r, mr, qrSvg='', rect;

      rect = 'l' + cellSize + ',0 0,' + cellSize +
        ' -' + cellSize + ',0 0,-' + cellSize + 'z ';

      qrSvg += '<svg version="1.1" xmlns="http://www.w3.org/2000/svg"';
      qrSvg += !opts.scalable ? ' width="' + size + 'px" height="' + size + 'px"' : '';
      qrSvg += ' viewBox="0 0 ' + size + ' ' + size + '" ';
      qrSvg += ' preserveAspectRatio="xMinYMin meet"';
      qrSvg += (title.text || alt.text) ? ' role="img" aria-labelledby="' +
          escapeXml([title.id, alt.id].join(' ').trim() ) + '"' : '';
      qrSvg += '>';
      qrSvg += (title.text) ? '<title id="' + escapeXml(title.id) + '">' +
          escapeXml(title.text) + '</title>' : '';
      qrSvg += (alt.text) ? '<description id="' + escapeXml(alt.id) + '">' +
          escapeXml(alt.text) + '</description>' : '';
      qrSvg += '<rect width="100%" height="100%" fill="white" cx="0" cy="0"/>';
      qrSvg += '<path d="';

      for (r = 0; r < _this.getModuleCount(); r += 1) {
        mr = r * cellSize + margin;
        for (c = 0; c < _this.getModuleCount(); c += 1) {
          if (_this.isDark(r, c) ) {
            mc = c*cellSize+margin;
            qrSvg += 'M' + mc + ',' + mr + rect;
          }
        }
      }

      qrSvg += '" stroke="transparent" fill="black"/>';
      qrSvg += '</svg>';

      return qrSvg;
    };

    _this.createDataURL = function(cellSize, margin) {

      cellSize = cellSize || 2;
      margin = (typeof margin == 'undefined')? cellSize * 4 : margin;

      var size = _this.getModuleCount() * cellSize + margin * 2;
      var min = margin;
      var max = size - margin;

      return createDataURL(size, size, function(x, y) {
        if (min <= x && x < max && min <= y && y < max) {
          var c = Math.floor( (x - min) / cellSize);
          var r = Math.floor( (y - min) / cellSize);
          return _this.isDark(r, c)? 0 : 1;
        } else {
          return 1;
        }
      } );
    };

    _this.createImgTag = function(cellSize, margin, alt) {

      cellSize = cellSize || 2;
      margin = (typeof margin == 'undefined')? cellSize * 4 : margin;

      var size = _this.getModuleCount() * cellSize + margin * 2;

      var img = '';
      img += '<img';
      img += '\u0020src="';
      img += _this.createDataURL(cellSize, margin);
      img += '"';
      img += '\u0020width="';
      img += size;
      img += '"';
      img += '\u0020height="';
      img += size;
      img += '"';
      if (alt) {
        img += '\u0020alt="';
        img += escapeXml(alt);
        img += '"';
      }
      img += '/>';

      return img;
    };

    var escapeXml = function(s) {
      var escaped = '';
      for (var i = 0; i < s.length; i += 1) {
        var c = s.charAt(i);
        switch(c) {
        case '<': escaped += '&lt;'; break;
        case '>': escaped += '&gt;'; break;
        case '&': escaped += '&amp;'; break;
        case '"': escaped += '&quot;'; break;
        default : escaped += c; break;
        }
      }
      return escaped;
    };

    var _createHalfASCII = function(margin) {
      var cellSize = 1;
      margin = (typeof margin == 'undefined')? cellSize * 2 : margin;

      var size = _this.getModuleCount() * cellSize + margin * 2;
      var min = margin;
      var max = size - margin;

      var y, x, r1, r2, p;

      var blocks = {
        '██': '█',
        '█ ': '▀',
        ' █': '▄',
        '  ': ' '
      };

      var blocksLastLineNoMargin = {
        '██': '▀',
        '█ ': '▀',
        ' █': ' ',
        '  ': ' '
      };

      var ascii = '';
      for (y = 0; y < size; y += 2) {
        r1 = Math.floor((y - min) / cellSize);
        r2 = Math.floor((y + 1 - min) / cellSize);
        for (x = 0; x < size; x += 1) {
          p = '█';

          if (min <= x && x < max && min <= y && y < max && _this.isDark(r1, Math.floor((x - min) / cellSize))) {
            p = ' ';
          }

          if (min <= x && x < max && min <= y+1 && y+1 < max && _this.isDark(r2, Math.floor((x - min) / cellSize))) {
            p += ' ';
          }
          else {
            p += '█';
          }

          // Output 2 characters per pixel, to create full square. 1 character per pixels gives only half width of square.
          ascii += (margin < 1 && y+1 >= max) ? blocksLastLineNoMargin[p] : blocks[p];
        }

        ascii += '\n';
      }

      if (size % 2 && margin > 0) {
        return ascii.substring(0, ascii.length - size - 1) + Array(size+1).join('▀');
      }

      return ascii.substring(0, ascii.length-1);
    };

    _this.createASCII = function(cellSize, margin) {
      cellSize = cellSize || 1;

      if (cellSize < 2) {
        return _createHalfASCII(margin);
      }

      cellSize -= 1;
      margin = (typeof margin == 'undefined')? cellSize * 2 : margin;

      var size = _this.getModuleCount() * cellSize + margin * 2;
      var min = margin;
      var max = size - margin;

      var y, x, r, p;

      var white = Array(cellSize+1).join('██');
      var black = Array(cellSize+1).join('  ');

      var ascii = '';
      var line = '';
      for (y = 0; y < size; y += 1) {
        r = Math.floor( (y - min) / cellSize);
        line = '';
        for (x = 0; x < size; x += 1) {
          p = 1;

          if (min <= x && x < max && min <= y && y < max && _this.isDark(r, Math.floor((x - min) / cellSize))) {
            p = 0;
          }

          // Output 2 characters per pixel, to create full square. 1 character per pixels gives only half width of square.
          line += p ? white : black;
        }

        for (r = 0; r < cellSize; r += 1) {
          ascii += line + '\n';
        }
      }

      return ascii.substring(0, ascii.length-1);
    };

    _this.renderTo2dContext = function(context, cellSize) {
      cellSize = cellSize || 2;
      var length = _this.getModuleCount();
      for (var row = 0; row < length; row++) {
        for (var col = 0; col < length; col++) {
          context.fillStyle = _this.isDark(row, col) ? 'black' : 'white';
          context.fillRect(row * cellSize, col * cellSize, cellSize, cellSize);
        }
      }
    }

    return _this;
  };

  //---------------------------------------------------------------------
  // qrcode.stringToBytes
  //---------------------------------------------------------------------

  qrcode.stringToBytesFuncs = {
    'default' : function(s) {
      var bytes = [];
      for (var i = 0; i < s.length; i += 1) {
        var c = s.charCodeAt(i);
        bytes.push(c & 0xff);
      }
      return bytes;
    }
  };

  qrcode.stringToBytes = qrcode.stringToBytesFuncs['default'];

  //---------------------------------------------------------------------
  // qrcode.createStringToBytes
  //---------------------------------------------------------------------

  /**
   * @param unicodeData base64 string of byte array.
   * [16bit Unicode],[16bit Bytes], ...
   * @param numChars
   */
  qrcode.createStringToBytes = function(unicodeData, numChars) {

    // create conversion map.

    var unicodeMap = function() {

      var bin = base64DecodeInputStream(unicodeData);
      var read = function() {
        var b = bin.read();
        if (b == -1) throw 'eof';
        return b;
      };

      var count = 0;
      var unicodeMap = {};
      while (true) {
        var b0 = bin.read();
        if (b0 == -1) break;
        var b1 = read();
        var b2 = read();
        var b3 = read();
        var k = String.fromCharCode( (b0 << 8) | b1);
        var v = (b2 << 8) | b3;
        unicodeMap[k] = v;
        count += 1;
      }
      if (count != numChars) {
        throw count + ' != ' + numChars;
      }

      return unicodeMap;
    }();

    var unknownChar = '?'.charCodeAt(0);

    return function(s) {
      var bytes = [];
      for (var i = 0; i < s.length; i += 1) {
        var c = s.charCodeAt(i);
        if (c < 128) {
          bytes.push(c);
        } else {
          var b = unicodeMap[s.charAt(i)];
          if (typeof b == 'number') {
            if ( (b & 0xff) == b) {
              // 1byte
              bytes.push(b);
            } else {
              // 2bytes
              bytes.push(b >>> 8);
              bytes.push(b & 0xff);
            }
          } else {
            bytes.push(unknownChar);
          }
        }
      }
      return bytes;
    };
  };

  //---------------------------------------------------------------------
  // QRMode
  //---------------------------------------------------------------------

  var QRMode = {
    MODE_NUMBER :    1 << 0,
    MODE_ALPHA_NUM : 1 << 1,
    MODE_8BIT_BYTE : 1 << 2,
    MODE_KANJI :     1 << 3
  };

  //---------------------------------------------------------------------
  // QRErrorCorrectionLevel
  //---------------------------------------------------------------------

  var QRErrorCorrectionLevel = {
    L : 1,
    M : 0,
    Q : 3,
    H : 2
  };

  //---------------------------------------------------------------------
  // QRMaskPattern
  //---------------------------------------------------------------------

  var QRMaskPattern = {
    PATTERN000 : 0,
    PATTERN001 : 1,
    PATTERN010 : 2,
    PATTERN011 : 3,
    PATTERN100 : 4,
    PATTERN101 : 5,
    PATTERN110 : 6,
    PATTERN111 : 7
  };

  //---------------------------------------------------------------------
  // QRUtil
  //---------------------------------------------------------------------

  var QRUtil = function() {

    var PATTERN_POSITION_TABLE = [
      [],
      [6, 18],
      [6, 22],
      [6, 26],
      [6, 30],
      [6, 34],
      [6, 22, 38],
      [6, 24, 42],
      [6, 26, 46],
      [6, 28, 50],
      [6, 30, 54],
      [6, 32, 58],
      [6, 34, 62],
      [6, 26, 46, 66],
      [6, 26, 48, 70],
      [6, 26, 50, 74],
      [6, 30, 54, 78],
      [6, 30, 56, 82],
      [6, 30, 58, 86],
      [6, 34, 62, 90],
      [6, 28, 50, 72, 94],
      [6, 26, 50, 74, 98],
      [6, 30, 54, 78, 102],
      [6, 28, 54, 80, 106],
      [6, 32, 58, 84, 110],
      [6, 30, 58, 86, 114],
      [6, 34, 62, 90, 118],
      [6, 26, 50, 74, 98, 122],
      [6, 30, 54, 78, 102, 126],
      [6, 26, 52, 78, 104, 130],
      [6, 30, 56, 82, 108, 134],
      [6, 34, 60, 86, 112, 138],
      [6, 30, 58, 86, 114, 142],
      [6, 34, 62, 90, 118, 146],
      [6, 30, 54, 78, 102, 126, 150],
      [6, 24, 50, 76, 102, 128, 154],
      [6, 28, 54, 80, 106, 132, 158],
      [6, 32, 58, 84, 110, 136, 162],
      [6, 26, 54, 82, 110, 138, 166],
      [6, 30, 58, 86, 114, 142, 170]
    ];
    var G15 = (1 << 10) | (1 << 8) | (1 << 5) | (1 << 4) | (1 << 2) | (1 << 1) | (1 << 0);
    var G18 = (1 << 12) | (1 << 11) | (1 << 10) | (1 << 9) | (1 << 8) | (1 << 5) | (1 << 2) | (1 << 0);
    var G15_MASK = (1 << 14) | (1 << 12) | (1 << 10) | (1 << 4) | (1 << 1);

    var _this = {};

    var getBCHDigit = function(data) {
      var digit = 0;
      while (data != 0) {
        digit += 1;
        data >>>= 1;
      }
      return digit;
    };

    _this.getBCHTypeInfo = function(data) {
      var d = data << 10;
      while (getBCHDigit(d) - getBCHDigit(G15) >= 0) {
        d ^= (G15 << (getBCHDigit(d) - getBCHDigit(G15) ) );
      }
      return ( (data << 10) | d) ^ G15_MASK;
    };

    _this.getBCHTypeNumber = function(data) {
      var d = data << 12;
      while (getBCHDigit(d) - getBCHDigit(G18) >= 0) {
        d ^= (G18 << (getBCHDigit(d) - getBCHDigit(G18) ) );
      }
      return (data << 12) | d;
    };

    _this.getPatternPosition = function(typeNumber) {
      return PATTERN_POSITION_TABLE[typeNumber - 1];
    };

    _this.getMaskFunction = function(maskPattern) {

      switch (maskPattern) {

      case QRMaskPattern.PATTERN000 :
        return function(i, j) { return (i + j) % 2 == 0; };
      case QRMaskPattern.PATTERN001 :
        return function(i, j) { return i % 2 == 0; };
      case QRMaskPattern.PATTERN010 :
        return function(i, j) { return j % 3 == 0; };
      case QRMaskPattern.PATTERN011 :
        return function(i, j) { return (i + j) % 3 == 0; };
      case QRMaskPattern.PATTERN100 :
        return function(i, j) { return (Math.floor(i / 2) + Math.floor(j / 3) ) % 2 == 0; };
      case QRMaskPattern.PATTERN101 :
        return function(i, j) { return (i * j) % 2 + (i * j) % 3 == 0; };
      case QRMaskPattern.PATTERN110 :
        return function(i, j) { return ( (i * j) % 2 + (i * j) % 3) % 2 == 0; };
      case QRMaskPattern.PATTERN111 :
        return function(i, j) { return ( (i * j) % 3 + (i + j) % 2) % 2 == 0; };

      default :
        throw 'bad maskPattern:' + maskPattern;
      }
    };

    _this.getErrorCorrectPolynomial = function(errorCorrectLength) {
      var a = qrPolynomial([1], 0);
      for (var i = 0; i < errorCorrectLength; i += 1) {
        a = a.multiply(qrPolynomial([1, QRMath.gexp(i)], 0) );
      }
      return a;
    };

    _this.getLengthInBits = function(mode, type) {

      if (1 <= type && type < 10) {

        // 1 - 9

        switch(mode) {
        case QRMode.MODE_NUMBER    : return 10;
        case QRMode.MODE_ALPHA_NUM : return 9;
        case QRMode.MODE_8BIT_BYTE : return 8;
        case QRMode.MODE_KANJI     : return 8;
        default :
          throw 'mode:' + mode;
        }

      } else if (type < 27) {

        // 10 - 26

        switch(mode) {
        case QRMode.MODE_NUMBER    : return 12;
        case QRMode.MODE_ALPHA_NUM : return 11;
        case QRMode.MODE_8BIT_BYTE : return 16;
        case QRMode.MODE_KANJI     : return 10;
        default :
          throw 'mode:' + mode;
        }

      } else if (type < 41) {

        // 27 - 40

        switch(mode) {
        case QRMode.MODE_NUMBER    : return 14;
        case QRMode.MODE_ALPHA_NUM : return 13;
        case QRMode.MODE_8BIT_BYTE : return 16;
        case QRMode.MODE_KANJI     : return 12;
        default :
          throw 'mode:' + mode;
        }

      } else {
        throw 'type:' + type;
      }
    };

    _this.getLostPoint = function(qrcode) {

      var moduleCount = qrcode.getModuleCount();

      var lostPoint = 0;

      // LEVEL1

      for (var row = 0; row < moduleCount; row += 1) {
        for (var col = 0; col < moduleCount; col += 1) {

          var sameCount = 0;
          var dark = qrcode.isDark(row, col);

          for (var r = -1; r <= 1; r += 1) {

            if (row + r < 0 || moduleCount <= row + r) {
              continue;
            }

            for (var c = -1; c <= 1; c += 1) {

              if (col + c < 0 || moduleCount <= col + c) {
                continue;
              }

              if (r == 0 && c == 0) {
                continue;
              }

              if (dark == qrcode.isDark(row + r, col + c) ) {
                sameCount += 1;
              }
            }
          }

          if (sameCount > 5) {
            lostPoint += (3 + sameCount - 5);
          }
        }
      };

      // LEVEL2

      for (var row = 0; row < moduleCount - 1; row += 1) {
        for (var col = 0; col < moduleCount - 1; col += 1) {
          var count = 0;
          if (qrcode.isDark(row, col) ) count += 1;
          if (qrcode.isDark(row + 1, col) ) count += 1;
          if (qrcode.isDark(row, col + 1) ) count += 1;
          if (qrcode.isDark(row + 1, col + 1) ) count += 1;
          if (count == 0 || count == 4) {
            lostPoint += 3;
          }
        }
      }

      // LEVEL3

      for (var row = 0; row < moduleCount; row += 1) {
        for (var col = 0; col < moduleCount - 6; col += 1) {
          if (qrcode.isDark(row, col)
              && !qrcode.isDark(row, col + 1)
              &&  qrcode.isDark(row, col + 2)
              &&  qrcode.isDark(row, col + 3)
              &&  qrcode.isDark(row, col + 4)
              && !qrcode.isDark(row, col + 5)
              &&  qrcode.isDark(row, col + 6) ) {
            lostPoint += 40;
          }
        }
      }

      for (var col = 0; col < moduleCount; col += 1) {
        for (var row = 0; row < moduleCount - 6; row += 1) {
          if (qrcode.isDark(row, col)
              && !qrcode.isDark(row + 1, col)
              &&  qrcode.isDark(row + 2, col)
              &&  qrcode.isDark(row + 3, col)
              &&  qrcode.isDark(row + 4, col)
              && !qrcode.isDark(row + 5, col)
              &&  qrcode.isDark(row + 6, col) ) {
            lostPoint += 40;
          }
        }
      }

      // LEVEL4

      var darkCount = 0;

      for (var col = 0; col < moduleCount; col += 1) {
        for (var row = 0; row < moduleCount; row += 1) {
          if (qrcode.isDark(row, col) ) {
            darkCount += 1;
          }
        }
      }

      var ratio = Math.abs(100 * darkCount / moduleCount / moduleCount - 50) / 5;
      lostPoint += ratio * 10;

      return lostPoint;
    };

    return _this;
  }();

  //---------------------------------------------------------------------
  // QRMath
  //---------------------------------------------------------------------

  var QRMath = function() {

    var EXP_TABLE = new Array(256);
    var LOG_TABLE = new Array(256);

    // initialize tables
    for (var i = 0; i < 8; i += 1) {
      EXP_TABLE[i] = 1 << i;
    }
    for (var i = 8; i < 256; i += 1) {
      EXP_TABLE[i] = EXP_TABLE[i - 4]
        ^ EXP_TABLE[i - 5]
        ^ EXP_TABLE[i - 6]
        ^ EXP_TABLE[i - 8];
    }
    for (var i = 0; i < 255; i += 1) {
      LOG_TABLE[EXP_TABLE[i] ] = i;
    }

    var _this = {};

    _this.glog = function(n) {

      if (n < 1) {
        throw 'glog(' + n + ')';
      }

      return LOG_TABLE[n];
    };

    _this.gexp = function(n) {

      while (n < 0) {
        n += 255;
      }

      while (n >= 256) {
        n -= 255;
      }

      return EXP_TABLE[n];
    };

    return _this;
  }();

  //---------------------------------------------------------------------
  // qrPolynomial
  //---------------------------------------------------------------------

  function qrPolynomial(num, shift) {

    if (typeof num.length == 'undefined') {
      throw num.length + '/' + shift;
    }

    var _num = function() {
      var offset = 0;
      while (offset < num.length && num[offset] == 0) {
        offset += 1;
      }
      var _num = new Array(num.length - offset + shift);
      for (var i = 0; i < num.length - offset; i += 1) {
        _num[i] = num[i + offset];
      }
      return _num;
    }();

    var _this = {};

    _this.getAt = function(index) {
      return _num[index];
    };

    _this.getLength = function() {
      return _num.length;
    };

    _this.multiply = function(e) {

      var num = new Array(_this.getLength() + e.getLength() - 1);

      for (var i = 0; i < _this.getLength(); i += 1) {
        for (var j = 0; j < e.getLength(); j += 1) {
          num[i + j] ^= QRMath.gexp(QRMath.glog(_this.getAt(i) ) + QRMath.glog(e.getAt(j) ) );
        }
      }

      return qrPolynomial(num, 0);
    };

    _this.mod = function(e) {

      if (_this.getLength() - e.getLength() < 0) {
        return _this;
      }

      var ratio = QRMath.glog(_this.getAt(0) ) - QRMath.glog(e.getAt(0) );

      var num = new Array(_this.getLength() );
      for (var i = 0; i < _this.getLength(); i += 1) {
        num[i] = _this.getAt(i);
      }

      for (var i = 0; i < e.getLength(); i += 1) {
        num[i] ^= QRMath.gexp(QRMath.glog(e.getAt(i) ) + ratio);
      }

      // recursive call
      return qrPolynomial(num, 0).mod(e);
    };

    return _this;
  };

  //---------------------------------------------------------------------
  // QRRSBlock
  //---------------------------------------------------------------------

  var QRRSBlock = function() {

    var RS_BLOCK_TABLE = [

      // L
      // M
      // Q
      // H

      // 1
      [1, 26, 19],
      [1, 26, 16],
      [1, 26, 13],
      [1, 26, 9],

      // 2
      [1, 44, 34],
      [1, 44, 28],
      [1, 44, 22],
      [1, 44, 16],

      // 3
      [1, 70, 55],
      [1, 70, 44],
      [2, 35, 17],
      [2, 35, 13],

      // 4
      [1, 100, 80],
      [2, 50, 32],
      [2, 50, 24],
      [4, 25, 9],

      // 5
      [1, 134, 108],
      [2, 67, 43],
      [2, 33, 15, 2, 34, 16],
      [2, 33, 11, 2, 34, 12],

      // 6
      [2, 86, 68],
      [4, 43, 27],
      [4, 43, 19],
      [4, 43, 15],

      // 7
      [2, 98, 78],
      [4, 49, 31],
      [2, 32, 14, 4, 33, 15],
      [4, 39, 13, 1, 40, 14],

      // 8
      [2, 121, 97],
      [2, 60, 38, 2, 61, 39],
      [4, 40, 18, 2, 41, 19],
      [4, 40, 14, 2, 41, 15],

      // 9
      [2, 146, 116],
      [3, 58, 36, 2, 59, 37],
      [4, 36, 16, 4, 37, 17],
      [4, 36, 12, 4, 37, 13],

      // 10
      [2, 86, 68, 2, 87, 69],
      [4, 69, 43, 1, 70, 44],
      [6, 43, 19, 2, 44, 20],
      [6, 43, 15, 2, 44, 16],

      // 11
      [4, 101, 81],
      [1, 80, 50, 4, 81, 51],
      [4, 50, 22, 4, 51, 23],
      [3, 36, 12, 8, 37, 13],

      // 12
      [2, 116, 92, 2, 117, 93],
      [6, 58, 36, 2, 59, 37],
      [4, 46, 20, 6, 47, 21],
      [7, 42, 14, 4, 43, 15],

      // 13
      [4, 133, 107],
      [8, 59, 37, 1, 60, 38],
      [8, 44, 20, 4, 45, 21],
      [12, 33, 11, 4, 34, 12],

      // 14
      [3, 145, 115, 1, 146, 116],
      [4, 64, 40, 5, 65, 41],
      [11, 36, 16, 5, 37, 17],
      [11, 36, 12, 5, 37, 13],

      // 15
      [5, 109, 87, 1, 110, 88],
      [5, 65, 41, 5, 66, 42],
      [5, 54, 24, 7, 55, 25],
      [11, 36, 12, 7, 37, 13],

      // 16
      [5, 122, 98, 1, 123, 99],
      [7, 73, 45, 3, 74, 46],
      [15, 43, 19, 2, 44, 20],
      [3, 45, 15, 13, 46, 16],

      // 17
      [1, 135, 107, 5, 136, 108],
      [10, 74, 46, 1, 75, 47],
      [1, 50, 22, 15, 51, 23],
      [2, 42, 14, 17, 43, 15],

      // 18
      [5, 150, 120, 1, 151, 121],
      [9, 69, 43, 4, 70, 44],
      [17, 50, 22, 1, 51, 23],
      [2, 42, 14, 19, 43, 15],

      // 19
      [3, 141, 113, 4, 142, 114],
      [3, 70, 44, 11, 71, 45],
      [17, 47, 21, 4, 48, 22],
      [9, 39, 13, 16, 40, 14],

      // 20
      [3, 135, 107, 5, 136, 108],
      [3, 67, 41, 13, 68, 42],
      [15, 54, 24, 5, 55, 25],
      [15, 43, 15, 10, 44, 16],

      // 21
      [4, 144, 116, 4, 145, 117],
      [17, 68, 42],
      [17, 50, 22, 6, 51, 23],
      [19, 46, 16, 6, 47, 17],

      // 22
      [2, 139, 111, 7, 140, 112],
      [17, 74, 46],
      [7, 54, 24, 16, 55, 25],
      [34, 37, 13],

      // 23
      [4, 151, 121, 5, 152, 122],
      [4, 75, 47, 14, 76, 48],
      [11, 54, 24, 14, 55, 25],
      [16, 45, 15, 14, 46, 16],

      // 24
      [6, 147, 117, 4, 148, 118],
      [6, 73, 45, 14, 74, 46],
      [11, 54, 24, 16, 55, 25],
      [30, 46, 16, 2, 47, 17],

      // 25
      [8, 132, 106, 4, 133, 107],
      [8, 75, 47, 13, 76, 48],
      [7, 54, 24, 22, 55, 25],
      [22, 45, 15, 13, 46, 16],

      // 26
      [10, 142, 114, 2, 143, 115],
      [19, 74, 46, 4, 75, 47],
      [28, 50, 22, 6, 51, 23],
      [33, 46, 16, 4, 47, 17],

      // 27
      [8, 152, 122, 4, 153, 123],
      [22, 73, 45, 3, 74, 46],
      [8, 53, 23, 26, 54, 24],
      [12, 45, 15, 28, 46, 16],

      // 28
      [3, 147, 117, 10, 148, 118],
      [3, 73, 45, 23, 74, 46],
      [4, 54, 24, 31, 55, 25],
      [11, 45, 15, 31, 46, 16],

      // 29
      [7, 146, 116, 7, 147, 117],
      [21, 73, 45, 7, 74, 46],
      [1, 53, 23, 37, 54, 24],
      [19, 45, 15, 26, 46, 16],

      // 30
      [5, 145, 115, 10, 146, 116],
      [19, 75, 47, 10, 76, 48],
      [15, 54, 24, 25, 55, 25],
      [23, 45, 15, 25, 46, 16],

      // 31
      [13, 145, 115, 3, 146, 116],
      [2, 74, 46, 29, 75, 47],
      [42, 54, 24, 1, 55, 25],
      [23, 45, 15, 28, 46, 16],

      // 32
      [17, 145, 115],
      [10, 74, 46, 23, 75, 47],
      [10, 54, 24, 35, 55, 25],
      [19, 45, 15, 35, 46, 16],

      // 33
      [17, 145, 115, 1, 146, 116],
      [14, 74, 46, 21, 75, 47],
      [29, 54, 24, 19, 55, 25],
      [11, 45, 15, 46, 46, 16],

      // 34
      [13, 145, 115, 6, 146, 116],
      [14, 74, 46, 23, 75, 47],
      [44, 54, 24, 7, 55, 25],
      [59, 46, 16, 1, 47, 17],

      // 35
      [12, 151, 121, 7, 152, 122],
      [12, 75, 47, 26, 76, 48],
      [39, 54, 24, 14, 55, 25],
      [22, 45, 15, 41, 46, 16],

      // 36
      [6, 151, 121, 14, 152, 122],
      [6, 75, 47, 34, 76, 48],
      [46, 54, 24, 10, 55, 25],
      [2, 45, 15, 64, 46, 16],

      // 37
      [17, 152, 122, 4, 153, 123],
      [29, 74, 46, 14, 75, 47],
      [49, 54, 24, 10, 55, 25],
      [24, 45, 15, 46, 46, 16],

      // 38
      [4, 152, 122, 18, 153, 123],
      [13, 74, 46, 32, 75, 47],
      [48, 54, 24, 14, 55, 25],
      [42, 45, 15, 32, 46, 16],

      // 39
      [20, 147, 117, 4, 148, 118],
      [40, 75, 47, 7, 76, 48],
      [43, 54, 24, 22, 55, 25],
      [10, 45, 15, 67, 46, 16],

      // 40
      [19, 148, 118, 6, 149, 119],
      [18, 75, 47, 31, 76, 48],
      [34, 54, 24, 34, 55, 25],
      [20, 45, 15, 61, 46, 16]
    ];

    var qrRSBlock = function(totalCount, dataCount) {
      var _this = {};
      _this.totalCount = totalCount;
      _this.dataCount = dataCount;
      return _this;
    };

    var _this = {};

    var getRsBlockTable = function(typeNumber, errorCorrectionLevel) {

      switch(errorCorrectionLevel) {
      case QRErrorCorrectionLevel.L :
        return RS_BLOCK_TABLE[(typeNumber - 1) * 4 + 0];
      case QRErrorCorrectionLevel.M :
        return RS_BLOCK_TABLE[(typeNumber - 1) * 4 + 1];
      case QRErrorCorrectionLevel.Q :
        return RS_BLOCK_TABLE[(typeNumber - 1) * 4 + 2];
      case QRErrorCorrectionLevel.H :
        return RS_BLOCK_TABLE[(typeNumber - 1) * 4 + 3];
      default :
        return undefined;
      }
    };

    _this.getRSBlocks = function(typeNumber, errorCorrectionLevel) {

      var rsBlock = getRsBlockTable(typeNumber, errorCorrectionLevel);

      if (typeof rsBlock == 'undefined') {
        throw 'bad rs block @ typeNumber:' + typeNumber +
            '/errorCorrectionLevel:' + errorCorrectionLevel;
      }

      var length = rsBlock.length / 3;

      var list = [];

      for (var i = 0; i < length; i += 1) {

        var count = rsBlock[i * 3 + 0];
        var totalCount = rsBlock[i * 3 + 1];
        var dataCount = rsBlock[i * 3 + 2];

        for (var j = 0; j < count; j += 1) {
          list.push(qrRSBlock(totalCount, dataCount) );
        }
      }

      return list;
    };

    return _this;
  }();

  //---------------------------------------------------------------------
  // qrBitBuffer
  //---------------------------------------------------------------------

  var qrBitBuffer = function() {

    var _buffer = [];
    var _length = 0;

    var _this = {};

    _this.getBuffer = function() {
      return _buffer;
    };

    _this.getAt = function(index) {
      var bufIndex = Math.floor(index / 8);
      return ( (_buffer[bufIndex] >>> (7 - index % 8) ) & 1) == 1;
    };

    _this.put = function(num, length) {
      for (var i = 0; i < length; i += 1) {
        _this.putBit( ( (num >>> (length - i - 1) ) & 1) == 1);
      }
    };

    _this.getLengthInBits = function() {
      return _length;
    };

    _this.putBit = function(bit) {

      var bufIndex = Math.floor(_length / 8);
      if (_buffer.length <= bufIndex) {
        _buffer.push(0);
      }

      if (bit) {
        _buffer[bufIndex] |= (0x80 >>> (_length % 8) );
      }

      _length += 1;
    };

    return _this;
  };

  //---------------------------------------------------------------------
  // qrNumber
  //---------------------------------------------------------------------

  var qrNumber = function(data) {

    var _mode = QRMode.MODE_NUMBER;
    var _data = data;

    var _this = {};

    _this.getMode = function() {
      return _mode;
    };

    _this.getLength = function(buffer) {
      return _data.length;
    };

    _this.write = function(buffer) {

      var data = _data;

      var i = 0;

      while (i + 2 < data.length) {
        buffer.put(strToNum(data.substring(i, i + 3) ), 10);
        i += 3;
      }

      if (i < data.length) {
        if (data.length - i == 1) {
          buffer.put(strToNum(data.substring(i, i + 1) ), 4);
        } else if (data.length - i == 2) {
          buffer.put(strToNum(data.substring(i, i + 2) ), 7);
        }
      }
    };

    var strToNum = function(s) {
      var num = 0;
      for (var i = 0; i < s.length; i += 1) {
        num = num * 10 + chatToNum(s.charAt(i) );
      }
      return num;
    };

    var chatToNum = function(c) {
      if ('0' <= c && c <= '9') {
        return c.charCodeAt(0) - '0'.charCodeAt(0);
      }
      throw 'illegal char :' + c;
    };

    return _this;
  };

  //---------------------------------------------------------------------
  // qrAlphaNum
  //---------------------------------------------------------------------

  var qrAlphaNum = function(data) {

    var _mode = QRMode.MODE_ALPHA_NUM;
    var _data = data;

    var _this = {};

    _this.getMode = function() {
      return _mode;
    };

    _this.getLength = function(buffer) {
      return _data.length;
    };

    _this.write = function(buffer) {

      var s = _data;

      var i = 0;

      while (i + 1 < s.length) {
        buffer.put(
          getCode(s.charAt(i) ) * 45 +
          getCode(s.charAt(i + 1) ), 11);
        i += 2;
      }

      if (i < s.length) {
        buffer.put(getCode(s.charAt(i) ), 6);
      }
    };

    var getCode = function(c) {

      if ('0' <= c && c <= '9') {
        return c.charCodeAt(0) - '0'.charCodeAt(0);
      } else if ('A' <= c && c <= 'Z') {
        return c.charCodeAt(0) - 'A'.charCodeAt(0) + 10;
      } else {
        switch (c) {
        case ' ' : return 36;
        case '$' : return 37;
        case '%' : return 38;
        case '*' : return 39;
        case '+' : return 40;
        case '-' : return 41;
        case '.' : return 42;
        case '/' : return 43;
        case ':' : return 44;
        default :
          throw 'illegal char :' + c;
        }
      }
    };

    return _this;
  };

  //---------------------------------------------------------------------
  // qr8BitByte
  //---------------------------------------------------------------------

  var qr8BitByte = function(data) {

    var _mode = QRMode.MODE_8BIT_BYTE;
    var _data = data;
    var _bytes = qrcode.stringToBytes(data);

    var _this = {};

    _this.getMode = function() {
      return _mode;
    };

    _this.getLength = function(buffer) {
      return _bytes.length;
    };

    _this.write = function(buffer) {
      for (var i = 0; i < _bytes.length; i += 1) {
        buffer.put(_bytes[i], 8);
      }
    };

    return _this;
  };

  //---------------------------------------------------------------------
  // qrKanji
  //---------------------------------------------------------------------

  var qrKanji = function(data) {

    var _mode = QRMode.MODE_KANJI;
    var _data = data;

    var stringToBytes = qrcode.stringToBytesFuncs['SJIS'];
    if (!stringToBytes) {
      throw 'sjis not supported.';
    }
    !function(c, code) {
      // self test for sjis support.
      var test = stringToBytes(c);
      if (test.length != 2 || ( (test[0] << 8) | test[1]) != code) {
        throw 'sjis not supported.';
      }
    }('\u53cb', 0x9746);

    var _bytes = stringToBytes(data);

    var _this = {};

    _this.getMode = function() {
      return _mode;
    };

    _this.getLength = function(buffer) {
      return ~~(_bytes.length / 2);
    };

    _this.write = function(buffer) {

      var data = _bytes;

      var i = 0;

      while (i + 1 < data.length) {

        var c = ( (0xff & data[i]) << 8) | (0xff & data[i + 1]);

        if (0x8140 <= c && c <= 0x9FFC) {
          c -= 0x8140;
        } else if (0xE040 <= c && c <= 0xEBBF) {
          c -= 0xC140;
        } else {
          throw 'illegal char at ' + (i + 1) + '/' + c;
        }

        c = ( (c >>> 8) & 0xff) * 0xC0 + (c & 0xff);

        buffer.put(c, 13);

        i += 2;
      }

      if (i < data.length) {
        throw 'illegal char at ' + (i + 1);
      }
    };

    return _this;
  };

  //=====================================================================
  // GIF Support etc.
  //

  //---------------------------------------------------------------------
  // byteArrayOutputStream
  //---------------------------------------------------------------------

  var byteArrayOutputStream = function() {

    var _bytes = [];

    var _this = {};

    _this.writeByte = function(b) {
      _bytes.push(b & 0xff);
    };

    _this.writeShort = function(i) {
      _this.writeByte(i);
      _this.writeByte(i >>> 8);
    };

    _this.writeBytes = function(b, off, len) {
      off = off || 0;
      len = len || b.length;
      for (var i = 0; i < len; i += 1) {
        _this.writeByte(b[i + off]);
      }
    };

    _this.writeString = function(s) {
      for (var i = 0; i < s.length; i += 1) {
        _this.writeByte(s.charCodeAt(i) );
      }
    };

    _this.toByteArray = function() {
      return _bytes;
    };

    _this.toString = function() {
      var s = '';
      s += '[';
      for (var i = 0; i < _bytes.length; i += 1) {
        if (i > 0) {
          s += ',';
        }
        s += _bytes[i];
      }
      s += ']';
      return s;
    };

    return _this;
  };

  //---------------------------------------------------------------------
  // base64EncodeOutputStream
  //---------------------------------------------------------------------

  var base64EncodeOutputStream = function() {

    var _buffer = 0;
    var _buflen = 0;
    var _length = 0;
    var _base64 = '';

    var _this = {};

    var writeEncoded = function(b) {
      _base64 += String.fromCharCode(encode(b & 0x3f) );
    };

    var encode = function(n) {
      if (n < 0) {
        // error.
      } else if (n < 26) {
        return 0x41 + n;
      } else if (n < 52) {
        return 0x61 + (n - 26);
      } else if (n < 62) {
        return 0x30 + (n - 52);
      } else if (n == 62) {
        return 0x2b;
      } else if (n == 63) {
        return 0x2f;
      }
      throw 'n:' + n;
    };

    _this.writeByte = function(n) {

      _buffer = (_buffer << 8) | (n & 0xff);
      _buflen += 8;
      _length += 1;

      while (_buflen >= 6) {
        writeEncoded(_buffer >>> (_buflen - 6) );
        _buflen -= 6;
      }
    };

    _this.flush = function() {

      if (_buflen > 0) {
        writeEncoded(_buffer << (6 - _buflen) );
        _buffer = 0;
        _buflen = 0;
      }

      if (_length % 3 != 0) {
        // padding
        var padlen = 3 - _length % 3;
        for (var i = 0; i < padlen; i += 1) {
          _base64 += '=';
        }
      }
    };

    _this.toString = function() {
      return _base64;
    };

    return _this;
  };

  //---------------------------------------------------------------------
  // base64DecodeInputStream
  //---------------------------------------------------------------------

  var base64DecodeInputStream = function(str) {

    var _str = str;
    var _pos = 0;
    var _buffer = 0;
    var _buflen = 0;

    var _this = {};

    _this.read = function() {

      while (_buflen < 8) {

        if (_pos >= _str.length) {
          if (_buflen == 0) {
            return -1;
          }
          throw 'unexpected end of file./' + _buflen;
        }

        var c = _str.charAt(_pos);
        _pos += 1;

        if (c == '=') {
          _buflen = 0;
          return -1;
        } else if (c.match(/^\s$/) ) {
          // ignore if whitespace.
          continue;
        }

        _buffer = (_buffer << 6) | decode(c.charCodeAt(0) );
        _buflen += 6;
      }

      var n = (_buffer >>> (_buflen - 8) ) & 0xff;
      _buflen -= 8;
      return n;
    };

    var decode = function(c) {
      if (0x41 <= c && c <= 0x5a) {
        return c - 0x41;
      } else if (0x61 <= c && c <= 0x7a) {
        return c - 0x61 + 26;
      } else if (0x30 <= c && c <= 0x39) {
        return c - 0x30 + 52;
      } else if (c == 0x2b) {
        return 62;
      } else if (c == 0x2f) {
        return 63;
      } else {
        throw 'c:' + c;
      }
    };

    return _this;
  };

  //---------------------------------------------------------------------
  // gifImage (B/W)
  //---------------------------------------------------------------------

  var gifImage = function(width, height) {

    var _width = width;
    var _height = height;
    var _data = new Array(width * height);

    var _this = {};

    _this.setPixel = function(x, y, pixel) {
      _data[y * _width + x] = pixel;
    };

    _this.write = function(out) {

      //---------------------------------
      // GIF Signature

      out.writeString('GIF87a');

      //---------------------------------
      // Screen Descriptor

      out.writeShort(_width);
      out.writeShort(_height);

      out.writeByte(0x80); // 2bit
      out.writeByte(0);
      out.writeByte(0);

      //---------------------------------
      // Global Color Map

      // black
      out.writeByte(0x00);
      out.writeByte(0x00);
      out.writeByte(0x00);

      // white
      out.writeByte(0xff);
      out.writeByte(0xff);
      out.writeByte(0xff);

      //---------------------------------
      // Image Descriptor

      out.writeString(',');
      out.writeShort(0);
      out.writeShort(0);
      out.writeShort(_width);
      out.writeShort(_height);
      out.writeByte(0);

      //---------------------------------
      // Local Color Map

      //---------------------------------
      // Raster Data

      var lzwMinCodeSize = 2;
      var raster = getLZWRaster(lzwMinCodeSize);

      out.writeByte(lzwMinCodeSize);

      var offset = 0;

      while (raster.length - offset > 255) {
        out.writeByte(255);
        out.writeBytes(raster, offset, 255);
        offset += 255;
      }

      out.writeByte(raster.length - offset);
      out.writeBytes(raster, offset, raster.length - offset);
      out.writeByte(0x00);

      //---------------------------------
      // GIF Terminator
      out.writeString(';');
    };

    var bitOutputStream = function(out) {

      var _out = out;
      var _bitLength = 0;
      var _bitBuffer = 0;

      var _this = {};

      _this.write = function(data, length) {

        if ( (data >>> length) != 0) {
          throw 'length over';
        }

        while (_bitLength + length >= 8) {
          _out.writeByte(0xff & ( (data << _bitLength) | _bitBuffer) );
          length -= (8 - _bitLength);
          data >>>= (8 - _bitLength);
          _bitBuffer = 0;
          _bitLength = 0;
        }

        _bitBuffer = (data << _bitLength) | _bitBuffer;
        _bitLength = _bitLength + length;
      };

      _this.flush = function() {
        if (_bitLength > 0) {
          _out.writeByte(_bitBuffer);
        }
      };

      return _this;
    };

    var getLZWRaster = function(lzwMinCodeSize) {

      var clearCode = 1 << lzwMinCodeSize;
      var endCode = (1 << lzwMinCodeSize) + 1;
      var bitLength = lzwMinCodeSize + 1;

      // Setup LZWTable
      var table = lzwTable();

      for (var i = 0; i < clearCode; i += 1) {
        table.add(String.fromCharCode(i) );
      }
      table.add(String.fromCharCode(clearCode) );
      table.add(String.fromCharCode(endCode) );

      var byteOut = byteArrayOutputStream();
      var bitOut = bitOutputStream(byteOut);

      // clear code
      bitOut.write(clearCode, bitLength);

      var dataIndex = 0;

      var s = String.fromCharCode(_data[dataIndex]);
      dataIndex += 1;

      while (dataIndex < _data.length) {

        var c = String.fromCharCode(_data[dataIndex]);
        dataIndex += 1;

        if (table.contains(s + c) ) {

          s = s + c;

        } else {

          bitOut.write(table.indexOf(s), bitLength);

          if (table.size() < 0xfff) {

            if (table.size() == (1 << bitLength) ) {
              bitLength += 1;
            }

            table.add(s + c);
          }

          s = c;
        }
      }

      bitOut.write(table.indexOf(s), bitLength);

      // end code
      bitOut.write(endCode, bitLength);

      bitOut.flush();

      return byteOut.toByteArray();
    };

    var lzwTable = function() {

      var _map = {};
      var _size = 0;

      var _this = {};

      _this.add = function(key) {
        if (_this.contains(key) ) {
          throw 'dup key:' + key;
        }
        _map[key] = _size;
        _size += 1;
      };

      _this.size = function() {
        return _size;
      };

      _this.indexOf = function(key) {
        return _map[key];
      };

      _this.contains = function(key) {
        return typeof _map[key] != 'undefined';
      };

      return _this;
    };

    return _this;
  };

  var createDataURL = function(width, height, getPixel) {
    var gif = gifImage(width, height);
    for (var y = 0; y < height; y += 1) {
      for (var x = 0; x < width; x += 1) {
        gif.setPixel(x, y, getPixel(x, y) );
      }
    }

    var b = byteArrayOutputStream();
    gif.write(b);

    var base64 = base64EncodeOutputStream();
    var bytes = b.toByteArray();
    for (var i = 0; i < bytes.length; i += 1) {
      base64.writeByte(bytes[i]);
    }
    base64.flush();

    return 'data:image/gif;base64,' + base64;
  };

  //---------------------------------------------------------------------
  // returns qrcode function.

  return qrcode;
}();

// multibyte support
!function() {

  qrcode.stringToBytesFuncs['UTF-8'] = function(s) {
    // http://stackoverflow.com/questions/18729405/how-to-convert-utf8-string-to-byte-array
    function toUTF8Array(str) {
      var utf8 = [];
      for (var i=0; i < str.length; i++) {
        var charcode = str.charCodeAt(i);
        if (charcode < 0x80) utf8.push(charcode);
        else if (charcode < 0x800) {
          utf8.push(0xc0 | (charcode >> 6),
              0x80 | (charcode & 0x3f));
        }
        else if (charcode < 0xd800 || charcode >= 0xe000) {
          utf8.push(0xe0 | (charcode >> 12),
              0x80 | ((charcode>>6) & 0x3f),
              0x80 | (charcode & 0x3f));
        }
        // surrogate pair
        else {
          i++;
          // UTF-16 encodes 0x10000-0x10FFFF by
          // subtracting 0x10000 and splitting the
          // 20 bits of 0x0-0xFFFFF into two halves
          charcode = 0x10000 + (((charcode & 0x3ff)<<10)
            | (str.charCodeAt(i) & 0x3ff));
          utf8.push(0xf0 | (charcode >>18),
              0x80 | ((charcode>>12) & 0x3f),
              0x80 | ((charcode>>6) & 0x3f),
              0x80 | (charcode & 0x3f));
        }
      }
      return utf8;
    }
    return toUTF8Array(s);
  };

}();

(function (factory) {
  if (typeof define === 'function' && define.amd) {
      define([], factory);
  } else if (typeof exports === 'object') {
      module.exports = factory();
  }
}(function () {
    return qrcode;
}));

// ── <xmr-pay> web component ─────────────────────────────────────────────────
// expects `qrcode` (vendored above) in scope. no other dependencies, no network
// calls except the merchant's own verify-url when the buyer submits a proof.

var XP_STR = {
    en: {
        sendExactly: 'Send exactly', anyAmount: 'Send any amount', awaiting: 'Awaiting payment', scanToSend: 'Scan or tap to send',
        addrLabel: 'Payment address — click to copy', copied: 'Copied ✓', openWallet: 'Open in wallet',
        trustToggle: 'Non-custodial · verify this payment',
        trustFunds: 'Funds go directly to the merchant’s wallet — this page never holds your money.',
        trustAddr: 'Check the address — it must start and end with:',
        trustAddrHint: 'Copy it and confirm with the merchant for large payments.',
        trustLink: 'Check the link — you are on',
        proveToggle: 'Paid but still waiting? Prove it',
        txidPh: 'Transaction ID (txid)', proofPh: 'Tx key or payment proof',
        proofHint: 'Feather: History → right-click the tx → Create tx proof. GUI: open the tx → “P”. Cake/Monerujo: tx details → transaction key. Paste it all in either box — txid and proof sort themselves out. Tip: a payment to this address is best proven with the tx PROOF.',
        verifyBtn: 'Verify payment', verifying: 'Verifying on-chain…', pasteBtn: 'Paste', pasteFail: 'Could not read the clipboard — paste manually',
        detectBtn: "I've paid — detect it", detecting: 'Checking the blockchain…', watching: 'Watching the blockchain for your payment…',
        paidTitle: 'Payment confirmed', confs: 'confirmations',
        overpaidMsg: 'You overpaid {x} XMR — contact the merchant for a refund of the difference.',
        receiptSigner: 'Signed by', receiptDownload: 'Download receipt', receiptVerify: 'Verify receipt',
        underpaid: 'Received {r} XMR, expected {e}',
        topupMsg: 'Detected {r} XMR — send {s} more to complete',
        topupTitle: 'Scan to send the difference',
        mempool: '✓ Payment received — confirming…',
        unconfirmed: 'Not confirmed yet — try again in a minute',
        confirming: '✓ Payment received — confirming ({c})…',
        replay: 'This transaction already paid another order',
        invalid: 'We couldn’t match this to your payment — check the transaction ID and proof are for THIS order',
        badTxid: 'That transaction ID looks off — it should be 64 characters. Copy the whole thing from your wallet',
        badProof: 'That doesn’t look like a payment proof — paste the tx key (64 chars) or the proof block (OutProof…/InProof…) from your wallet',
        'no-funds': 'This transaction sent nothing to this address',
        'node-disagreement': 'Nodes disagreed — try again',
        'node-error': 'Nodes are unavailable — try again in a moment',
        locked: 'Funds are time-locked — payment not accepted',
        netErr: 'Network error — try again',
        foot: 'Non-custodial — funds go directly to the merchant.',
        signedBy: 'Signed · {fp}', unsigned: 'Unsigned — verify the address with the merchant',
        badTitle: 'Signature check failed', badBody: 'This payment claims to be signed but the signature does not match. Do not pay. Contact the merchant.',
        disclaimer: 'Verify the address before sending. Monero payments are final and cannot be reversed. This widget is provided as-is, with no warranty.',
    },
    es: {
        sendExactly: 'Envía exactamente', anyAmount: 'Envía cualquier cantidad', awaiting: 'Esperando pago', scanToSend: 'Escanea o toca para enviar',
        addrLabel: 'Dirección de pago — clic para copiar', copied: 'Copiada ✓', openWallet: 'Abrir en wallet',
        trustToggle: 'No-custodial · verifica este pago',
        trustFunds: 'Los fondos van directo a la wallet del comerciante — esta página nunca toca tu dinero.',
        trustAddr: 'Comprueba la dirección — debe empezar y terminar con:',
        trustAddrHint: 'Cópiala y confírmala con el comerciante en pagos grandes.',
        trustLink: 'Comprueba el enlace — estás en',
        proveToggle: '¿Pagaste y sigue esperando? Demuéstralo',
        txidPh: 'ID de transacción (txid)', proofPh: 'Tx key o prueba de pago',
        proofHint: 'Feather: History → clic derecho en la tx → Create tx proof. GUI: abre la tx → “P”. Cake/Monerujo: detalles de la tx → transaction key. Pega todo en cualquier caja — txid y prueba se acomodan solos. Tip: un pago a esta dirección se prueba mejor con la tx PROOF.',
        verifyBtn: 'Verificar pago', verifying: 'Verificando en cadena…', pasteBtn: 'Pegar', pasteFail: 'No se pudo leer el portapapeles — pega a mano',
        detectBtn: 'Ya pagué — detectar', detecting: 'Revisando la blockchain…', watching: 'Esperando tu pago en la blockchain…',
        paidTitle: 'Pago confirmado', confs: 'confirmaciones',
        overpaidMsg: 'Pagaste {x} XMR de más — contacta al comerciante para el reembolso de la diferencia.',
        receiptSigner: 'Firmado por', receiptDownload: 'Descargar recibo', receiptVerify: 'Verificar recibo',
        underpaid: 'Se recibió {r} XMR, se esperaban {e}',
        topupMsg: 'Detectado {r} XMR — envía {s} más para completar',
        topupTitle: 'Escanea para enviar la diferencia',
        mempool: '✓ Pago recibido — confirmando…',
        unconfirmed: 'Aún sin confirmar — prueba en un minuto',
        confirming: '✓ Pago recibido — confirmando ({c})…',
        replay: 'Esta transacción ya pagó otra orden',
        invalid: 'No pudimos relacionarlo con tu pago — revisa que el ID de transacción y la prueba sean de ESTA orden',
        badTxid: 'Ese ID de transacción no cuadra — debe tener 64 caracteres. Copia el completo desde tu wallet',
        badProof: 'Eso no parece una prueba de pago — pega la tx key (64 caracteres) o el bloque (OutProof…/InProof…) de tu wallet',
        'no-funds': 'Esta transacción no envió nada a esta dirección',
        'node-disagreement': 'Los nodos no coinciden — reintenta',
        'node-error': 'Nodos no disponibles — reintenta en un momento',
        locked: 'Los fondos están bloqueados en el tiempo — pago no aceptado',
        netErr: 'Error de red — reintenta',
        foot: 'No-custodial — los fondos van directo al comerciante.',
        signedBy: 'Firmado · {fp}', unsigned: 'Sin firmar — verifica la dirección con el comerciante',
        badTitle: 'Falló la verificación de firma', badBody: 'Este pago dice estar firmado pero la firma no coincide. No pagues. Contacta al comerciante.',
        disclaimer: 'Verifica la dirección antes de enviar. Los pagos en Monero son finales e irreversibles. Este widget se ofrece tal cual, sin garantía.',
    },
};

// two skins, one component. default = "clean" (universal, rounded, system
// sans). skin="brutal" flips to the goxmr look (mono, square, hard offset
// shadow). every color/shape is a css custom property so any brand can retheme
// without forking.
var XP_CSS = [
    ':host{--xp-accent:#FF6600;--xp-qr:#F26822;--xp-bg:#1b1b1f;--xp-fg:#f7f7f8;--xp-muted:#9b9ba4;',
    '--xp-border:#33333b;--xp-input:#26262d;--xp-green:#22c55e;--xp-yellow:#eab308;--xp-red:#f87171;',
    '--xp-radius:14px;--xp-radius-sm:9px;--xp-bw:1px;--xp-bw-in:1px;--xp-shadow:0 10px 30px rgba(0,0,0,.35);',
    '--xp-font:system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;--xp-mono:ui-monospace,"SF Mono",SFMono-Regular,Menlo,Consolas,monospace;',
    '--xp-case:none;--xp-track:.01em;--xp-btn-bg:var(--xp-accent);--xp-btn-fg:#fff;--xp-btn-hv:#e25c00;--xp-qr-border:#e8e8ec;',
    'display:block;max-width:400px;font-family:var(--xp-font);}',
    ':host([theme=light]){--xp-bg:#fff;--xp-fg:#141417;--xp-muted:#6e6e78;--xp-border:#e5e5ea;--xp-input:#f4f4f6;--xp-shadow:0 10px 26px rgba(0,0,0,.10);}',
    ':host([skin=brutal]){--xp-bg:#18181b;--xp-fg:#fafafa;--xp-muted:#a1a1aa;--xp-border:#fff;--xp-input:#27272a;',
    '--xp-radius:0;--xp-radius-sm:0;--xp-bw:3px;--xp-bw-in:2px;--xp-shadow:7px 7px 0 0 var(--xp-qr);',
    '--xp-font:var(--xp-mono);--xp-case:uppercase;--xp-track:.04em;--xp-btn-bg:var(--xp-fg);--xp-btn-fg:var(--xp-bg);--xp-btn-hv:var(--xp-accent);--xp-qr-border:#000;}',
    ':host([skin=brutal][theme=light]){--xp-bg:#fff;--xp-fg:#0a0a0a;--xp-muted:#52525b;--xp-border:#000;--xp-input:#f4f4f5;}',
    '*{box-sizing:border-box;margin:0;}',
    '.card{background:var(--xp-bg);color:var(--xp-fg);border:var(--xp-bw) solid var(--xp-border);border-radius:var(--xp-radius);box-shadow:var(--xp-shadow);overflow:hidden;}',
    '.hd{padding:14px 16px;border-bottom:var(--xp-bw-in) solid var(--xp-border);}',
    '.lbl{font-size:10px;text-transform:uppercase;letter-spacing:.07em;color:var(--xp-muted);}',
    '.amt{font-size:26px;font-weight:800;color:var(--xp-accent);line-height:1.1;margin-top:3px;font-family:var(--xp-mono);}',
    '.st{font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:var(--xp-track);margin-top:7px;color:var(--xp-yellow);}',
    '.st.paid{color:var(--xp-green);}',
    '.qrwrap{display:flex;justify-content:center;padding:16px 16px 10px;}',
    '.qr{background:#fff;padding:8px;border:var(--xp-bw-in) solid var(--xp-qr-border);border-radius:var(--xp-radius-sm);width:228px;height:228px;}',
    '.qr svg{display:block;width:100%;height:100%;}',
    '.sec{padding:0 16px 12px;}',
    '.addr{width:100%;background:var(--xp-input);border:var(--xp-bw-in) solid var(--xp-border);border-radius:var(--xp-radius-sm);color:var(--xp-fg);',
    'font-family:var(--xp-mono);font-size:10.5px;text-align:left;padding:8px;word-break:break-all;cursor:pointer;line-height:1.5;}',
    '.addr:hover{background:var(--xp-accent);color:#fff;}',
    '.addr b{color:var(--xp-accent);font-weight:800;} .addr:hover b{color:#fff;}',
    '.wallet{display:block;text-align:center;margin-top:8px;background:var(--xp-btn-bg);color:var(--xp-btn-fg);border:var(--xp-bw-in) solid transparent;border-radius:var(--xp-radius-sm);',
    'font-family:var(--xp-font);font-size:12px;font-weight:700;text-transform:var(--xp-case);letter-spacing:var(--xp-track);text-decoration:none;padding:11px;}',
    '.wallet:hover{background:var(--xp-btn-hv);color:#fff;}',
    '.tgl{width:100%;background:none;border:0;border-top:1px solid var(--xp-input);color:var(--xp-muted);font-family:var(--xp-font);',
    'font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:var(--xp-track);padding:10px 4px;cursor:pointer;display:flex;justify-content:space-between;gap:8px;}',
    '.tgl:hover{color:var(--xp-accent);} .tgl .car{transition:transform .15s;} .tgl.open .car{transform:rotate(180deg);}',
    '.fold{border:var(--xp-bw-in) solid var(--xp-border);border-radius:var(--xp-radius-sm);padding:10px;margin-bottom:10px;font-size:10px;color:var(--xp-muted);line-height:1.55;}',
    '.fold p{margin-bottom:7px;} .fold b{color:var(--xp-fg);text-transform:uppercase;}',
    '.fp{display:block;border:var(--xp-bw-in) solid var(--xp-border);border-radius:var(--xp-radius-sm);background:var(--xp-input);padding:6px 8px;margin:4px 0;color:var(--xp-fg);word-break:break-all;font-family:var(--xp-mono);}',
    '.fp b{color:var(--xp-accent);}',
    '.in{width:100%;background:var(--xp-input);border:var(--xp-bw-in) solid var(--xp-border);border-radius:var(--xp-radius-sm);color:var(--xp-fg);font-family:var(--xp-mono);font-size:10.5px;padding:8px;margin-bottom:7px;}',
    'textarea.in{resize:vertical;min-height:46px;word-break:break-all;}',
    '.go{width:100%;background:var(--xp-btn-bg);color:var(--xp-btn-fg);border:var(--xp-bw-in) solid transparent;border-radius:var(--xp-radius-sm);font-family:var(--xp-font);font-size:12px;',
    'font-weight:800;text-transform:var(--xp-case);letter-spacing:var(--xp-track);padding:10px;cursor:pointer;}',
    '.go:hover{background:var(--xp-btn-hv);color:#fff;} .go:disabled{opacity:.45;cursor:not-allowed;}',
    '.prow{display:flex;gap:8px;} .prow .verify{flex:1;} .prow .paste{flex:0 0 auto;width:auto;padding-left:16px;padding-right:16px;background:transparent;color:var(--xp-fg);border-color:var(--xp-border);}',
    '.prow .paste:hover{background:var(--xp-accent);color:#fff;border-color:var(--xp-accent);}',
    ':host *:focus-visible{outline:2px solid var(--xp-accent);outline-offset:2px;}',
    ':host([skin=brutal]) .wallet,:host([skin=brutal]) .go{border-color:var(--xp-border);}',
    '.res{margin-top:7px;font-size:10px;font-weight:700;} .res.bad{color:var(--xp-red);} .res.mid{color:var(--xp-yellow);}',
    '.topup{margin-top:9px;padding:11px;border:1px solid var(--xp-input);border-radius:var(--xp-radius-sm);text-align:center;}',
    '.topup .ta{font-family:var(--xp-mono);font-size:14px;font-weight:800;color:var(--xp-accent);letter-spacing:var(--xp-track);margin-top:2px;}',
    '.topup .tq{width:150px;height:150px;background:#fff;padding:7px;margin:8px auto;border:var(--xp-bw-in) solid var(--xp-qr-border);border-radius:var(--xp-radius-sm);}',
    '.topup .tq svg{display:block;width:100%;height:100%;}',
    '.topup .wallet{margin-top:4px;}',
    '.hint{margin-top:7px;font-size:9px;color:var(--xp-muted);line-height:1.5;}',
    '.foot{padding:10px 16px;border-top:1px solid var(--xp-input);font-size:9px;color:var(--xp-muted);text-align:center;}',
    '.ok{padding:26px 16px;text-align:center;}',
    '.ring{width:54px;height:54px;border:3px solid var(--xp-green);border-radius:50%;display:flex;align-items:center;justify-content:center;',
    'margin:0 auto 10px;color:var(--xp-green);font-size:26px;}',
    '.ok .t{font-size:13px;font-weight:800;text-transform:var(--xp-case);}',
    '.ok .over{margin:12px auto 0;max-width:280px;font-size:11px;line-height:1.5;color:var(--xp-amber,#f59e0b);border:1px solid var(--xp-amber,#f59e0b);border-radius:6px;padding:8px 10px;}',
    '.ok .c{font-size:10px;color:var(--xp-muted);margin-top:5px;}',
    '.rcpt{margin-top:16px;display:flex;flex-direction:column;gap:8px;align-items:center;}',
    '.rcpt .fp{font-size:9px;color:var(--xp-muted);letter-spacing:var(--xp-track);word-break:break-all;}',
    '.rcpt .lk{display:inline-block;font-size:11px;font-weight:700;text-decoration:none;padding:8px 14px;border-radius:var(--xp-radius-sm);border:var(--xp-bw-in) solid var(--xp-border);color:var(--xp-fg);text-transform:var(--xp-case);}',
    '.rcpt .lk[download]{background:var(--xp-accent);color:#000;border-color:transparent;}',
    '.watch{display:flex;flex-direction:column;gap:8px;}',
    '.detect{width:100%;background:var(--xp-btn-bg);color:var(--xp-btn-fg);border:0;border-radius:var(--xp-radius-sm);padding:11px;font-weight:800;font-size:13px;cursor:pointer;font-family:inherit;text-transform:var(--xp-case);letter-spacing:var(--xp-track);}',
    '.detect:hover{background:var(--xp-btn-hv);}',
    '.detect:disabled{opacity:.55;cursor:default;}',
    '.wst{font-size:11px;color:var(--xp-yellow);text-align:center;margin:0;}',
    '.hidden{display:none;}',
].join('');

function xpQrSvg(text) {
    var qr = qrcode(0, 'M');
    qr.addData(text);
    qr.make();
    var n = qr.getModuleCount(), s = 4, q = 2, size = (n + q * 2) * s, rects = '';
    function fin(r, c) { return (r < 7 && c < 7) || (r < 7 && c >= n - 7) || (r >= n - 7 && c < 7); }
    for (var r = 0; r < n; r++) for (var c = 0; c < n; c++) {
        if (!qr.isDark(r, c)) continue;
        rects += '<rect x="' + (c + q) * s + '" y="' + (r + q) * s + '" width="' + s + '" height="' + s +
            '" fill="' + (fin(r, c) ? '#000' : '#F26822') + '"/>';
    }
    return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ' + size + ' ' + size + '" shape-rendering="crispEdges" role="img" aria-label="Monero payment QR code">' + rects + '</svg>';
}

function xpEsc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (ch) {
        return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ch];
    });
}

// canonical XMR decimal for the monero: URI's tx_amount — trims trailing zeros
// and surrounding space so every wallet (Feather, GUI, CLI, Cake, Monerujo,
// Stack…) prefills the same clean amount. matches src/core.js picoToXmrString,
// the form round-trip-tested against the official wallet2 parser. odd inputs are
// left untouched (the amount is validated server-side regardless).
function xpNormAmount(a) {
    a = String(a == null ? '' : a).trim();
    if (!/^\d+(\.\d{1,12})?$/.test(a)) return a;
    if (a.indexOf('.') < 0) return a;
    return a.replace(/0+$/, '').replace(/\.$/, '');
}

// signed-config verification, browser side. mirrors src/config.js exactly so a
// config signed in node verifies here. Ed25519 via WebCrypto (modern browsers).
function xpCanonical(v) {
    if (v === null || typeof v !== 'object') return JSON.stringify(v);
    if (Array.isArray(v)) return '[' + v.map(xpCanonical).join(',') + ']';
    return '{' + Object.keys(v).sort().map(function (k) { return JSON.stringify(k) + ':' + xpCanonical(v[k]); }).join(',') + '}';
}
function xpB64ToBytes(b64) { var s = atob(b64); var a = new Uint8Array(s.length); for (var i = 0; i < s.length; i++) a[i] = s.charCodeAt(i); return a; }
function xpPemToDer(pem) { return xpB64ToBytes(pem.replace(/-----[^-]+-----/g, '').replace(/\s+/g, '')); }
async function xpFingerprint(der) {
    // 12 bytes / 96 bits — must match configFingerprint() in src/config.js, or a
    // pinned fingerprint never matches what the widget computes.
    var h = new Uint8Array(await crypto.subtle.digest('SHA-256', der));
    var hex = ''; for (var i = 0; i < 12; i++) hex += h[i].toString(16).padStart(2, '0');
    return hex.match(/.{4}/g).join('-');
}
async function xpVerifyConfig(env) {
    try {
        if (!env || !env.config || !env.sig || !env.pubkey) return { valid: false };
        var der = xpPemToDer(env.pubkey);
        var key = await crypto.subtle.importKey('spki', der, { name: 'Ed25519' }, false, ['verify']);
        var sig = xpB64ToBytes(env.sig);
        var msg = new TextEncoder().encode(xpCanonical(env.config));
        var ok = await crypto.subtle.verify('Ed25519', key, sig, msg);
        return { valid: ok, fingerprint: await xpFingerprint(der), config: env.config };
    } catch (e) { return { valid: false, error: e && e.message }; }
}

class XmrPay extends HTMLElement {
    static get observedAttributes() { return ['address', 'amount', 'label', 'order', 'verify-url', 'status-url', 'stream-url', 'lang', 'redirect-url', 'theme']; }

    connectedCallback() { this._resolve().then(() => this._render()); }
    disconnectedCallback() { this._closeStream(); clearTimeout(this._watchT); clearTimeout(this._repollT); }
    _closeStream() { if (this._es) { try { this._es.close(); } catch (e) {} this._es = null; } this._streaming = false; }
    attributeChangedCallback() { if (this.isConnected) this._resolve().then(() => this._render()); }

    // work out the effective address/amount and the signing state before render.
    // a `config` attribute (base64 signed envelope) overrides inline attrs and,
    // if its signature is bad or fails a pin, suppresses the pay UI entirely.
    async _resolve() {
        var cfg = this.getAttribute('config');
        if (!cfg) {
            this._addr = (this.getAttribute('address') || '').trim();
            this._amount = (this.getAttribute('amount') || '').trim();
            this._sign = { state: 'unsigned' };
            return;
        }
        try {
            var env = JSON.parse(atob(cfg));
            var v = await xpVerifyConfig(env);
            // pinning: a `pubkey` is the signer's FULL key — compare its DER bytes
            // (formatting-agnostic), not as if it were a fingerprint. a `fingerprint`
            // is the short hex id. either one, when set, must match the signer.
            var pinnedPub = (this.getAttribute('pubkey') || '').trim();
            var pinnedFp = (this.getAttribute('fingerprint') || '').trim();
            var pinned = true;
            if (pinnedPub) {
                try {
                    var a = xpPemToDer(pinnedPub), b = xpPemToDer(env.pubkey);
                    pinned = a.length === b.length && a.every(function (x, i) { return x === b[i]; });
                } catch (e) { pinned = false; }
            } else if (pinnedFp) {
                pinned = !!v.fingerprint && pinnedFp.replace(/[^a-f0-9]/gi, '').toLowerCase() === v.fingerprint.replace(/-/g, '');
            }
            if (v.valid && pinned) {
                this._addr = (env.config.address || '').trim();
                this._amount = (env.config.amount != null ? String(env.config.amount) : '').trim();
                this._sign = { state: 'ok', fp: v.fingerprint };
            } else {
                this._addr = ''; this._amount = '';
                this._sign = { state: 'bad' };
            }
        } catch (e) {
            this._addr = ''; this._amount = '';
            this._sign = { state: 'bad' };
        }
    }

    get _t() {
        var lang = this.getAttribute('lang') ||
            ((document.documentElement.lang || navigator.language || 'en').toLowerCase().indexOf('es') === 0 ? 'es' : 'en');
        return XP_STR[lang] || XP_STR.en;
    }

    _uri() {
        var label = this.getAttribute('label');
        var p = [];
        if (this._amount) p.push('tx_amount=' + encodeURIComponent(xpNormAmount(this._amount)));
        if (label) p.push('tx_description=' + encodeURIComponent(label));
        return 'monero:' + (this._addr || '') + (p.length ? '?' + p.join('&') : '');
    }

    _render() {
        var t = this._t;
        var addr = this._addr || '';
        var amount = this._amount || '';
        var verifyUrl = (this.getAttribute('verify-url') || '').trim();
        var statusUrl = (this.getAttribute('status-url') || '').trim();
        var sign = this._sign || { state: 'unsigned' };
        var root = this.shadowRoot || this.attachShadow({ mode: 'open' });

        // a config that claims to be signed but doesn't verify (or fails a pin)
        // never shows a payable address — it's the loudest failure mode we have.
        if (sign.state === 'bad') {
            root.innerHTML = '<style>' + XP_CSS + '</style>' +
                '<div class="card"><div class="hd"><div class="st" style="color:var(--xp-red)">⚠ ' + t.badTitle + '</div></div>' +
                '<div class="sec" style="padding:14px 16px"><p class="hint" style="font-size:11px;color:var(--xp-red)">' + t.badBody + '</p></div></div>';
            return;
        }
        if (!/^[1-9A-HJ-NP-Za-km-z]{95}$/.test(addr)) {
            root.innerHTML = '<style>' + XP_CSS + '</style><div class="card"><div class="hd"><div class="lbl">xmr-pay</div>' +
                '<div class="st" style="color:var(--xp-red)">missing or invalid address attribute</div></div></div>';
            return;
        }

        var fpHead = xpEsc(addr.slice(0, 8)), fpTail = xpEsc(addr.slice(-8)), fpMid = xpEsc(addr.slice(8, -8));
        var host = location.host || location.hostname || '';

        root.innerHTML =
            '<style>' + XP_CSS + '</style>' +
            '<div class="card">' +
            '<div class="hd">' +
            '<div class="lbl">' + (amount ? t.sendExactly : t.anyAmount) + (this.getAttribute('label') ? ' · ' + xpEsc(this.getAttribute('label')) : '') + '</div>' +
            (amount ? '<div class="amt">' + xpEsc(amount) + ' XMR</div>' : '') +
            '<div class="st">' + (verifyUrl ? '● ' + t.awaiting : t.scanToSend) + '</div>' +
            '</div>' +
            '<div class="body">' +
            '<div class="qrwrap"><div class="qr">' + xpQrSvg(this._uri()) + '</div></div>' +
            '<div class="sec">' +
            '<div class="lbl" style="margin-bottom:4px">' + t.addrLabel + '</div>' +
            '<button class="addr" type="button" aria-label="' + t.addrLabel + '"><b>' + fpHead + '</b>' + fpMid + '<b>' + fpTail + '</b></button>' +
            '<a class="wallet" href="' + xpEsc(this._uri()) + '">' + t.openWallet + '</a>' +
            '</div>' +
            // watch mode: the agent is already scanning (view key), so the buyer
            // just taps "detect" — no txid/proof to paste. auto-polls too.
            (statusUrl ?
                '<div class="sec watch">' +
                '<button class="go detect" type="button">' + t.detectBtn + '</button>' +
                '<p class="wst" role="status" aria-live="polite">● ' + t.watching + '</p>' +
                '</div>'
                : '') +
            '<div class="sec">' +
            '<button class="tgl trust-toggle" type="button" aria-expanded="false"><span>⛨ ' + t.trustToggle + '</span><span class="car">▾</span></button>' +
            '<div class="fold trust-body hidden">' +
            (sign.state === 'ok'
                ? '<p style="color:var(--xp-green)"><b>⛨ ' + t.signedBy.replace('{fp}', xpEsc(sign.fp)) + '</b></p>'
                : '<p class="hint">' + t.unsigned + '</p>') +
            '<p>' + t.trustFunds + '</p>' +
            '<p><b>' + t.trustAddr + '</b></p>' +
            '<span class="fp"><b>' + fpHead + '</b> … <b>' + fpTail + '</b></span>' +
            '<p class="hint">' + t.trustAddrHint + '</p>' +
            '<p><b>' + t.trustLink + '</b> <span style="color:var(--xp-accent)">' + xpEsc(host) + '</span></p>' +
            '<p class="hint" style="border-top:1px solid var(--xp-input);padding-top:8px;margin-top:4px">' + t.disclaimer + '</p>' +
            '</div>' +
            (verifyUrl ?
                '<button class="tgl prove-toggle" type="button" aria-expanded="false"><span>' + t.proveToggle + '</span><span class="car">▾</span></button>' +
                '<div class="fold prove-body hidden">' +
                '<input class="in txid" spellcheck="false" autocapitalize="off" autocomplete="off" aria-label="' + t.txidPh + '" placeholder="' + t.txidPh + '">' +
                '<textarea class="in proof" rows="2" spellcheck="false" autocapitalize="off" aria-label="' + t.proofPh + '" placeholder="' + t.proofPh + '"></textarea>' +
                '<div class="prow">' +
                '<button class="go paste" type="button">' + t.pasteBtn + '</button>' +
                '<button class="go verify" type="button">' + t.verifyBtn + '</button>' +
                '</div>' +
                '<p class="res hidden" role="status" aria-live="polite"></p>' +
                '<div class="topup hidden" role="status" aria-live="polite"></div>' +
                '<p class="hint">' + t.proofHint + '</p>' +
                '</div>'
                : '') +
            '</div>' +
            '</div>' +
            '<div class="foot">' + t.foot + '</div>' +
            '</div>';

        this._wire(root, addr, verifyUrl, t);
    }

    _wire(root, addr, verifyUrl, t) {
        var self = this;
        var addrBtn = root.querySelector('.addr');
        addrBtn.addEventListener('click', function () {
            var done = function () {
                var old = addrBtn.innerHTML;
                addrBtn.textContent = t.copied;
                setTimeout(function () { addrBtn.innerHTML = old; }, 1600);
            };
            if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(addr).then(done, done);
            else done();
        });

        root.querySelectorAll('.tgl').forEach(function (tgl) {
            tgl.addEventListener('click', function () {
                var open = tgl.classList.toggle('open');
                tgl.setAttribute('aria-expanded', open ? 'true' : 'false');
                var body = tgl.nextElementSibling;
                if (body) body.classList.toggle('hidden');
            });
        });

        var verifyBtn = root.querySelector('.verify');
        if (verifyBtn) verifyBtn.addEventListener('click', function () { self._verify(root, verifyUrl, t); });

        // watch mode: wire the "detect" button, open a push stream if offered, and
        // auto-poll the status URL. the stream (SSE) updates the buyer in seconds;
        // the poll stays as a backup so a buffering proxy can't make a payment look
        // lost — it just slows to a heartbeat cadence when a stream is live.
        var statusUrl = (this.getAttribute('status-url') || '').trim();
        var streamUrl = (this.getAttribute('stream-url') || '').trim();
        var detectBtn = root.querySelector('.detect');
        if (statusUrl || streamUrl) {
            this._paidDone = false;
            if (detectBtn && statusUrl) detectBtn.addEventListener('click', function () { self._watch(root, statusUrl, t, true); });
            this._closeStream();
            if (streamUrl && typeof EventSource !== 'undefined') this._stream(root, streamUrl, t);
            if (statusUrl) {
                clearTimeout(this._watchT);
                this._watchT = setTimeout(function () { self._watch(root, statusUrl, t, false); }, 1500);
            }
        }

        // smart paste: Feather's "formatted proof" (and similar) is one text
        // block with txid + address + signature. accept the whole thing in
        // either box and sort the pieces out.
        var txidIn = root.querySelector('.txid'), proofIn = root.querySelector('.proof');
        var split = function (el) {
            var v = el.value;
            if (!v || v.length < 70) return;
            var proof = (v.match(/(?:Out|In)Proof[Vv]?\d?[1-9A-HJ-NP-Za-km-z]{40,}/) || [null])[0];
            var hexes = v.match(/\b[0-9a-fA-F]{64}\b/g) || [];
            var txid = hexes[0] || null;
            var key = proof || (hexes.length > 1 ? hexes[1] : null);
            if (txid && key && txid !== key) { txidIn.value = txid.toLowerCase(); proofIn.value = key; }
        };
        if (txidIn && proofIn) {
            [txidIn, proofIn].forEach(function (el) { el.addEventListener('input', function () { split(el); }); });
        }

        // mobile-friendly: read the clipboard and let smart-split sort it. needs
        // a user gesture + HTTPS; falls back to a hint if the browser refuses.
        var pasteBtn = root.querySelector('.paste');
        if (pasteBtn && txidIn && proofIn) {
            pasteBtn.addEventListener('click', function () {
                if (!navigator.clipboard || !navigator.clipboard.readText) { self._showRes(root, t.pasteFail, 'bad'); return; }
                navigator.clipboard.readText().then(function (text) {
                    if (!text) return;
                    proofIn.value = text.trim();
                    split(proofIn);
                    proofIn.focus();
                }, function () { self._showRes(root, t.pasteFail, 'bad'); });
            });
        }
    }

    _showRes(root, msg, kind) {
        var res = root.querySelector('.res');
        if (!res) return;
        res.textContent = msg;
        res.className = 'res ' + (kind || '');
    }

    async _verify(root, verifyUrl, t) {
        var txid = root.querySelector('.txid').value.trim();
        var proof = root.querySelector('.proof').value.trim();
        var res = root.querySelector('.res');
        var btn = root.querySelector('.verify');
        if (!txid) { root.querySelector('.txid').focus(); return; }
        if (!proof) { root.querySelector('.proof').focus(); return; }
        // catch the common paste mistakes BEFORE a server round-trip, with a
        // specific message so the buyer can fix it on the spot.
        if (!/^[0-9a-f]{64}$/i.test(txid)) { this._showRes(root, t.badTxid, 'bad'); root.querySelector('.txid').focus(); return; }
        if (!(/^[0-9a-f]{64}$/i.test(proof) || /^(Out|In)Proof/i.test(proof))) { this._showRes(root, t.badProof, 'bad'); root.querySelector('.proof').focus(); return; }

        btn.disabled = true; btn.textContent = t.verifying;
        res.classList.add('hidden');
        var out = null;
        try {
            var r = await fetch(verifyUrl, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ order_id: this.getAttribute('order') || null, txid: txid, proof: proof }),
            });
            out = await r.json();
        } catch (e) {
            out = { paid: false, status: 'netErr' };
        }
        btn.disabled = false; btn.textContent = t.verifyBtn;

        this.dispatchEvent(new CustomEvent('xmr-pay:result', { detail: out, bubbles: true, composed: true }));

        if (out && out.paid) { this._success(root, out, t); return; }

        var status = (out && (out.status || out.error)) || 'invalid';
        var msg = t[status] || (out && out.error) || t.invalid;
        var topup = root.querySelector('.topup');
        if (topup) { topup.className = 'topup hidden'; topup.innerHTML = ''; }
        if (status === 'underpaid') {
            var recv = out.receivedXmr != null ? out.receivedXmr : '?';
            if (out.shortfallXmr != null) {
                // the server computed the missing amount in piconero (exact). show
                // it AND a QR for EXACTLY the difference so the buyer can top up —
                // no mental math, no chance to send the wrong amount.
                msg = t.topupMsg.replace('{r}', recv).replace('{s}', out.shortfallXmr);
                if (topup) {
                    var tUri = 'monero:' + (this._addr || '') + '?tx_amount=' + encodeURIComponent(out.shortfallXmr);
                    var tLbl = this.getAttribute('label'); if (tLbl) tUri += '&tx_description=' + encodeURIComponent(tLbl);
                    topup.innerHTML =
                        '<div class="lbl">' + t.topupTitle + '</div>' +
                        '<div class="ta">' + xpEsc(out.shortfallXmr) + ' XMR</div>' +
                        '<div class="tq">' + xpQrSvg(tUri) + '</div>' +
                        '<a class="wallet" href="' + xpEsc(tUri) + '">' + t.openWallet + '</a>';
                    topup.className = 'topup';
                }
            } else {
                // older server without shortfallXmr — fall back to expected amount.
                var exp = out.expectedXmr != null ? out.expectedXmr : (this.getAttribute('amount') || '—');
                msg = t.underpaid.replace('{r}', recv).replace('{e}', exp);
            }
        }
        // proof mode LIVE progress: a mempool/unconfirmed payment WILL confirm —
        // show the real confirmation count and re-check on a timer until it's paid,
        // so the buyer watches it climb instead of being told to "try again later".
        if (status === 'unconfirmed' && out && out.confirmations != null) {
            msg = t.confirming.replace('{c}', out.confirmations);
        }
        res.textContent = msg;
        res.className = 'res ' + (status === 'mempool' || status === 'unconfirmed' || status === 'node-error' ? 'mid' : 'bad');
        clearTimeout(this._repollT);
        if (status === 'mempool' || status === 'unconfirmed') {
            var self = this;
            this._repollT = setTimeout(function () { self._verify(root, verifyUrl, t); }, 15000);
        }
    }

    // push stream: connect to the agent's SSE channel (stream-url). each event is a
    // full status snapshot — same shape as the poll — so detection lands in seconds
    // with no polling lag. the browser auto-reconnects on a dropped connection; the
    // backup poll keeps running (slowed) so a proxy that buffers SSE can't strand a
    // payment. closed once paid (or on disconnect).
    _stream(root, streamUrl, t) {
        var self = this;
        var es;
        try { es = new EventSource(streamUrl); } catch (e) { return; }
        this._es = es;
        this._streaming = true;
        es.onmessage = function (ev) {
            var out; try { out = JSON.parse(ev.data); } catch (e) { return; }
            self._applyWatch(root, out, t);
        };
        es.onerror = function () { /* keep the poll backup; EventSource auto-reconnects */ };
    }

    // watch mode poll: GET the status URL (the agent /order/:id or a proxy) and
    // react. no proof to paste — the agent is already scanning the chain. keeps
    // polling on mempool/unconfirmed; on paid → _success (→ receipt). `manual`
    // is a buyer-triggered "detect" click (shows button feedback).
    async _watch(root, statusUrl, t, manual) {
        if (this._paidDone || !this.isConnected) return;
        var self = this;
        var btn = root.querySelector('.detect');
        if (manual && btn) { btn.disabled = true; btn.textContent = t.detecting; }
        var out = null;
        try {
            var r = await fetch(statusUrl, { headers: { Accept: 'application/json' } });
            out = await r.json();
        } catch (e) { out = { reachable: false }; }
        if (manual && btn) { btn.disabled = false; btn.textContent = t.detectBtn; }
        if (this._paidDone) return;
        this._applyWatch(root, out, t);
        // backup cadence: brisk when polling alone, a slow heartbeat when a push
        // stream is carrying the live updates.
        clearTimeout(this._watchT);
        var active = out && (out.status === 'mempool' || out.status === 'unconfirmed');
        var delay = this._streaming ? 20000 : (active ? 8000 : 6000);
        this._watchT = setTimeout(function () { self._watch(root, statusUrl, t, false); }, delay);
    }

    // fold one status snapshot (from a poll OR a stream event) into the UI.
    _applyWatch(root, out, t) {
        if (this._paidDone) return;
        if (out && out.paid) {
            this._paidDone = true; clearTimeout(this._watchT); this._closeStream();
            this.dispatchEvent(new CustomEvent('xmr-pay:result', { detail: out, bubbles: true, composed: true }));
            this._success(root, out, t);
            return;
        }
        var wst = root.querySelector('.wst');
        if (wst) {
            var status = out && out.status;
            var msg;
            // lead with "payment received" the instant a tx is seen (mempool/unconfirmed)
            // so the buyer feels done and stops worrying — it's only confirmations left.
            if (status === 'mempool') msg = t.mempool;
            else if (status === 'unconfirmed' && out.confirmations != null) msg = t.confirming.replace('{c}', out.confirmations);
            else if ((status === 'partial' || status === 'underpaid') && out.shortfallXmr != null) msg = t.topupMsg.replace('{r}', out.receivedXmr != null ? out.receivedXmr : '?').replace('{s}', out.shortfallXmr);
            else msg = '● ' + t.watching;
            wst.textContent = msg;
            wst.className = 'wst' + (status === 'mempool' || status === 'unconfirmed' ? ' mid' : '');
        }
    }

    _success(root, out, t) {
        this._paidDone = true;
        clearTimeout(this._repollT);
        clearTimeout(this._watchT);
        var st = root.querySelector('.st');
        if (st) { st.textContent = '✓ ' + t.paidTitle; st.classList.add('paid'); }
        var body = root.querySelector('.body');
        body.innerHTML = '<div class="ok"><div class="ring">✓</div><div class="t">' + t.paidTitle + '</div>' +
            '<div class="c">' + (out.confirmations != null ? out.confirmations + ' ' + t.confs : '') + '</div>' +
            (out.overpaid ? '<div class="over">' + t.overpaidMsg.replace('{x}', xpEsc(String(out.overpaidXmr != null ? out.overpaidXmr : ''))) + '</div>' : '') +
            '<div class="rcpt hidden"></div></div>';
        // the cryptographic receipt — engine-level, so ANY embedder gets it (not
        // just WooCommerce). on paid, fetch the merchant-signed receipt and show a
        // download + a one-click link to the offline verifier.
        var hasReceipt = !!( this.getAttribute('receipt-url') || '' ).trim();
        if (hasReceipt) this._receipt(root, t);
        // UX signal ONLY — this runs in the buyer's browser, so a buyer can fire
        // this event (or fake this whole success state) from the console. NEVER
        // release goods on it. Fulfill on YOUR server's verifyPayment + order
        // record. (Same rule as Stripe: the client is not the authority.)
        this.dispatchEvent(new CustomEvent('xmr-pay:paid', { detail: out, bubbles: true, composed: true }));
        // auto-redirect is opt-in (redirect-url). but a downloadable receipt must
        // not be yanked away — when one is shown, keep the buyer on the page.
        // SANITIZE: only an absolute http(s) URL or a single-slash same-origin path
        // is followed. NEVER a javascript:/data:/protocol-relative value — location
        // .assign('javascript:…') EXECUTES it (XSS). the embedder sets this attribute,
        // but a value from untrusted input must not become script execution.
        var redirect = this.getAttribute('redirect-url') || '';
        var safeRedirect = (/^https?:\/\//i.test(redirect) || /^\/[^/]/.test(redirect)) ? redirect : '';
        if (safeRedirect && !hasReceipt) setTimeout(function () { location.assign(safeRedirect); }, 2500);
    }

    // fetch the signed receipt (from receipt-url, the agent /receipt/:id or a
    // store proxy) and render the download + verifier links. verify-page points
    // at the offline verifier (default 'verify-receipt.html'); the receipt rides
    // in its URL #fragment so the verifier needs no backend.
    async _receipt(root, t) {
        var url  = ( this.getAttribute('receipt-url') || '' ).trim();
        var page = ( this.getAttribute('verify-page') || 'verify-receipt.html' ).trim();
        var box  = root.querySelector('.rcpt');
        if (!url || !box) return;
        // the agent may still be minting the receipt (the on-chain tx_proof can
        // take a moment) → it answers 409 until ready. retry a few times before
        // giving up, so a freshly-paid order still shows its receipt.
        var env = null;
        for (var i = 0; i < 6 && !env; i++) {
            try {
                var r = await fetch(url, { headers: { Accept: 'application/json' } });
                if (r.ok) { env = await r.json(); break; }
                if (r.status !== 409) return;   // a real error (404/401) — stop
            } catch (e) { /* transient — retry */ }
            await new Promise(function (res) { setTimeout(res, 2000); });
        }
        if (!env || !env.sig || !env.receipt) return;
        var b64 = btoa(unescape(encodeURIComponent(JSON.stringify(env))));
        var dl  = 'data:application/json;charset=utf-8;base64,' + b64;
        var verify = page + '#' + b64.replace(/\+/g, '-').replace(/\//g, '_');
        var fp = env.fingerprint ? '<div class="fp">' + xpEsc(t.receiptSigner + ' ' + env.fingerprint) + '</div>' : '';
        box.innerHTML = fp +
            '<a class="lk" download="receipt.json" href="' + dl + '">↓ ' + xpEsc(t.receiptDownload) + '</a>' +
            '<a class="lk" target="_blank" rel="noopener" href="' + xpEsc(verify) + '">↗ ' + xpEsc(t.receiptVerify) + '</a>';
        box.classList.remove('hidden');
    }
}

if (!customElements.get('xmr-pay')) customElements.define('xmr-pay', XmrPay);
})();
